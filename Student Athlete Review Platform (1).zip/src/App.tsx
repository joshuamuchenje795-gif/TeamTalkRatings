import { useState } from 'react';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select';
import { HeroSection } from './components/HeroSection';
import { TrendingPrograms } from './components/TrendingPrograms';
import { SearchResults } from './components/SearchResults';
import { LoginDialog } from './components/LoginDialog';
import { RateProgramDialog } from './components/RateProgramDialog';
import { LogIn, Search, X } from 'lucide-react';
import logoImage from 'figma:asset/1069712d54ab5e29b924cc6acfd3b0c34e19a1b5.png';
import { schools, allSports, divisions, School } from './data/schools-complete';

export default function App() {
  const [sport, setSport] = useState('');
  const [division, setDivision] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<School[] | null>(null);
  const [showResults, setShowResults] = useState(false);
  const [loginDialogOpen, setLoginDialogOpen] = useState(false);
  const [rateProgramDialogOpen, setRateProgramDialogOpen] = useState(false);

  const handleSearch = () => {
    let filtered = schools;

    // Filter by sport
    if (sport && sport !== 'all') {
      filtered = filtered.filter((school) => 
        school.sports.some((s) => s.toLowerCase() === sport.toLowerCase())
      );
    }

    // Filter by division
    if (division && division !== 'all') {
      filtered = filtered.filter((school) => school.division === division);
    }

    // Filter by search query (school name)
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter((school) => 
        school.name.toLowerCase().includes(query) ||
        school.state.toLowerCase().includes(query)
      );
    }

    setSearchResults(filtered);
    setShowResults(true);
  };

  const handleClearSearch = () => {
    setSport('');
    setDivision('');
    setSearchQuery('');
    setSearchResults(null);
    setShowResults(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const handleSearchPrograms = () => {
    setShowResults(true);
    // Scroll to search section
    window.scrollTo({ top: 300, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#001f3f] flex flex-col">
      {/* Login Dialog */}
      <LoginDialog open={loginDialogOpen} onOpenChange={setLoginDialogOpen} />
      
      {/* Rate Program Dialog */}
      <RateProgramDialog open={rateProgramDialogOpen} onOpenChange={setRateProgramDialogOpen} />

      {/* Header */}
      <header className="bg-[#001f3f] border-b-2 border-[#d4af37] sticky top-0 z-50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex-1" />
            <div className="flex items-center justify-center flex-1">
              <button onClick={handleClearSearch}>
                <img src={logoImage} alt="Portal Index Logo" className="h-20 object-contain mix-blend-lighten opacity-95" />
              </button>
            </div>
            
            {/* Navigation */}
            <div className="flex-1 flex items-center justify-end gap-4">
              <Button 
                onClick={() => setLoginDialogOpen(true)}
                className="bg-[#d4af37] text-[#001f3f] hover:bg-[#f4d03f]"
              >
                <LogIn className="size-4 mr-2" />
                Log In / Sign Up
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 w-full">
        {/* Hero Section */}
        {!showResults && (
          <HeroSection 
            onRateProgram={() => setRateProgramDialogOpen(true)}
            onSearchPrograms={handleSearchPrograms}
          />
        )}

        {/* Search Section */}
        <section className="bg-[#003366] py-12">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col gap-4">
              <div className="flex flex-col md:flex-row gap-4 items-end">
                <div className="flex-1">
                  <label className="text-white text-sm mb-2 block">Division</label>
                  <Select value={division} onValueChange={setDivision}>
                    <SelectTrigger className="w-full bg-[#001f3f] text-white border-[#d4af37] h-14">
                      <SelectValue placeholder="All Divisions" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Divisions</SelectItem>
                      {divisions.map((div) => (
                        <SelectItem key={div} value={div}>{div}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex-1">
                  <label className="text-white text-sm mb-2 block">Sport</label>
                  <Select value={sport} onValueChange={setSport}>
                    <SelectTrigger className="w-full bg-[#001f3f] text-white border-[#d4af37] h-14">
                      <SelectValue placeholder="All Sports" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Sports</SelectItem>
                      {allSports.map((sportName) => (
                        <SelectItem key={sportName} value={sportName}>{sportName}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex-[2]">
                  <label className="text-white text-sm mb-2 block">School Name or State</label>
                  <Input
                    placeholder="Search by school or state"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyPress={handleKeyPress}
                    className="w-full bg-[#001f3f] text-white border-[#d4af37] placeholder:text-gray-400 h-14"
                  />
                </div>

                <Button 
                  onClick={handleSearch}
                  className="bg-[#0066cc] hover:bg-[#0052a3] text-white h-14 px-8"
                >
                  <Search className="size-5 mr-2" />
                  SEARCH
                </Button>

                {showResults && (
                  <Button 
                    onClick={handleClearSearch}
                    variant="outline"
                    className="border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37]/10 h-14 px-6"
                  >
                    <X className="size-5 mr-2" />
                    CLEAR
                  </Button>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* Search Results or Trending Programs */}
        {showResults && searchResults ? (
          <section className="bg-[#001f3f] py-16">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <SearchResults results={searchResults} />
            </div>
          </section>
        ) : (
          <TrendingPrograms />
        )}

        {/* Bottom CTA */}
        {!showResults && (
          <section className="bg-[#001f3f] py-16 border-t-2 border-[#d4af37]">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
              <h2 className="text-white mb-2">
                EMPOWERING ATHLETES,{' '}
                <span className="text-[#d4af37]">CHANGING RECRUITING FOREVER.</span>
              </h2>
            </div>
          </section>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-[#001529] border-t-2 border-[#d4af37]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            {/* Company */}
            <div>
              <h3 className="text-[#d4af37] mb-4">Company</h3>
              <ul className="space-y-2">
                <li>
                  <button className="text-white hover:text-[#d4af37] transition-colors text-left">
                    About Us
                  </button>
                </li>
                <li>
                  <button className="text-white hover:text-[#d4af37] transition-colors text-left">
                    Mission
                  </button>
                </li>
                <li>
                  <button className="text-white hover:text-[#d4af37] transition-colors text-left">
                    Partners
                  </button>
                </li>
              </ul>
            </div>

            {/* Support */}
            <div>
              <h3 className="text-[#d4af37] mb-4">Support</h3>
              <ul className="space-y-2">
                <li>
                  <button className="text-white hover:text-[#d4af37] transition-colors text-left">
                    Contact Us
                  </button>
                </li>
                <li>
                  <button className="text-white hover:text-[#d4af37] transition-colors text-left">
                    Help Center
                  </button>
                </li>
              </ul>
            </div>

            {/* Legal */}
            <div>
              <h3 className="text-[#d4af37] mb-4">Legal</h3>
              <ul className="space-y-2">
                <li>
                  <button className="text-white hover:text-[#d4af37] transition-colors text-left">
                    Terms and Conditions
                  </button>
                </li>
                <li>
                  <button className="text-white hover:text-[#d4af37] transition-colors text-left">
                    Privacy Policy
                  </button>
                </li>
              </ul>
            </div>

            {/* Portal Index Logo */}
            <div className="flex flex-col items-start md:items-end">
              <img src={logoImage} alt="Portal Index Logo" className="h-16 object-contain mix-blend-lighten opacity-90 mb-4" />
              <p className="text-sm text-gray-400 text-left md:text-right">
                Empowering student athletes with transparent reviews and insights.
              </p>
            </div>
          </div>

          {/* Copyright */}
          <div className="pt-6 border-t border-[#d4af37]/30">
            <p className="text-center text-sm text-gray-400">
              © {new Date().getFullYear()} Portal Index. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}