import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Star, MapPin, Users, TrendingUp, Building2, GraduationCap, Trophy } from 'lucide-react';
import { useState } from 'react';

interface University {
  id: number;
  name: string;
  division: string;
  conference: string;
  location: string;
  overallRating: number;
  facilitiesRating: number;
  coachingRating: number;
  academicsRating: number;
  athleticProgramRating: number;
  reviewCount: number;
  sports: string[];
}

interface UniversityCardProps {
  university: University;
  onWriteReview: () => void;
}

export function UniversityCard({ university, onWriteReview }: UniversityCardProps) {
  const [showDetails, setShowDetails] = useState(false);

  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`size-4 ${
              star <= rating
                ? 'fill-yellow-400 text-yellow-400'
                : star - rating < 1
                ? 'fill-yellow-200 text-yellow-400'
                : 'fill-gray-200 text-gray-200'
            }`}
          />
        ))}
        <span className="ml-2 text-gray-700">{rating.toFixed(1)}</span>
      </div>
    );
  };

  const ratingCategories = [
    { name: 'Facilities', rating: university.facilitiesRating, icon: Building2, color: 'blue' },
    { name: 'Coaching', rating: university.coachingRating, icon: Users, color: 'green' },
    { name: 'Academics', rating: university.academicsRating, icon: GraduationCap, color: 'purple' },
    { name: 'Athletic Program', rating: university.athleticProgramRating, icon: Trophy, color: 'orange' }
  ];

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow border-l-4 border-l-[#d4af37]">
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h3 className="text-[#001f3f]">{university.name}</h3>
              <Badge variant="secondary" className="bg-[#001f3f] text-white hover:bg-[#003366]">{university.division}</Badge>
            </div>
            <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600">
              <div className="flex items-center gap-1">
                <MapPin className="size-4" />
                {university.location}
              </div>
              <div className="flex items-center gap-1">
                <TrendingUp className="size-4" />
                {university.conference}
              </div>
              <div className="text-gray-500">
                {university.reviewCount} reviews
              </div>
            </div>
          </div>
          
          <div className="text-right">
            <div className="flex items-center gap-2 mb-1">
              <Star className="size-6 fill-yellow-400 text-yellow-400" />
              <span className="text-gray-900">{university.overallRating.toFixed(1)}</span>
            </div>
            <p className="text-xs text-gray-500">Overall Rating</p>
          </div>
        </div>

        {/* Sports */}
        <div className="flex flex-wrap gap-2 mb-4">
          {university.sports.map(sport => (
            <Badge key={sport} variant="outline" className="text-xs">
              {sport}
            </Badge>
          ))}
        </div>

        {/* Rating Details */}
        {showDetails && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4 p-4 bg-gray-50 rounded-lg">
            {ratingCategories.map(({ name, rating, icon: Icon, color }) => (
              <div key={name} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Icon className="size-4 text-gray-600" />
                    <span className="text-sm text-gray-700">{name}</span>
                  </div>
                  <span className="text-sm text-gray-900">{rating.toFixed(1)}</span>
                </div>
                <Progress value={rating * 20} className="h-2" />
              </div>
            ))}
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-3">
          <Button
            variant="outline"
            className="flex-1"
            onClick={() => setShowDetails(!showDetails)}
          >
            {showDetails ? 'Hide' : 'Show'} Details
          </Button>
          <Button onClick={onWriteReview} className="flex-1">
            Write a Review
          </Button>
        </div>
      </div>
    </Card>
  );
}