import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Star, MapPin } from 'lucide-react';
import { School } from '../data/schools';

interface SearchResultsProps {
  results: School[];
  onSelectSchool?: (school: School) => void;
}

export function SearchResults({ results, onSelectSchool }: SearchResultsProps) {
  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`size-4 ${
              star <= Math.floor(rating)
                ? 'fill-[#d4af37] text-[#d4af37]'
                : 'fill-gray-600 text-gray-600'
            }`}
          />
        ))}
      </div>
    );
  };

  if (results.length === 0) {
    return (
      <div className="text-center py-16">
        <p className="text-gray-400 text-lg">No schools found matching your criteria.</p>
        <p className="text-gray-500 text-sm mt-2">Try adjusting your search filters.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-white text-xl">
          {results.length} {results.length === 1 ? 'School' : 'Schools'} Found
        </h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {results.map((school) => (
          <Card 
            key={school.id} 
            className="bg-[#001529] border-[#d4af37]/30 hover:border-[#d4af37] transition-all hover:shadow-lg hover:shadow-[#d4af37]/20"
          >
            <div className="p-6">
              {/* School Name */}
              <h4 className="text-white mb-3 min-h-[3rem]">{school.name}</h4>

              {/* Division & Location */}
              <div className="flex items-center gap-2 mb-4">
                <Badge className="bg-[#0066cc] text-white hover:bg-[#0052a3]">
                  {school.division}
                </Badge>
                <div className="flex items-center gap-1 text-gray-400 text-sm">
                  <MapPin className="size-3" />
                  {school.state}
                </div>
              </div>

              {/* Rating */}
              {school.overallRating && (
                <div className="flex items-center gap-2 mb-4 pb-4 border-b border-gray-700">
                  {renderStars(school.overallRating)}
                  <span className="text-white">{school.overallRating}</span>
                  {school.totalReviews && (
                    <span className="text-gray-400 text-sm">({school.totalReviews} reviews)</span>
                  )}
                </div>
              )}

              {/* Sports */}
              <div className="mb-4">
                <p className="text-gray-400 text-sm mb-2">Sports Offered:</p>
                <div className="flex flex-wrap gap-1">
                  {school.sports.slice(0, 4).map((sport) => (
                    <Badge 
                      key={sport} 
                      variant="outline" 
                      className="border-[#d4af37]/50 text-[#d4af37] text-xs"
                    >
                      {sport}
                    </Badge>
                  ))}
                  {school.sports.length > 4 && (
                    <Badge 
                      variant="outline" 
                      className="border-gray-600 text-gray-400 text-xs"
                    >
                      +{school.sports.length - 4} more
                    </Badge>
                  )}
                </div>
              </div>

              {/* View Profile Button */}
              <Button 
                onClick={() => onSelectSchool?.(school)}
                className="w-full bg-[#d4af37] text-[#001f3f] hover:bg-[#f4d03f]"
              >
                VIEW PROFILE
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
