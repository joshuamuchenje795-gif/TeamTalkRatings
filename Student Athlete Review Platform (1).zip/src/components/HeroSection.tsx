import { Button } from './ui/button';
import { Card } from './ui/card';
import { Star, MessageSquare, TrendingUp } from 'lucide-react';

interface HeroSectionProps {
  onRateProgram: () => void;
  onSearchPrograms: () => void;
}

export function HeroSection({ onRateProgram, onSearchPrograms }: HeroSectionProps) {
  return (
    <section className="bg-gradient-to-b from-[#001f3f] to-[#003366] py-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Headline */}
        <div className="text-center mb-12">
          <h1 className="text-white mb-4">
            RATE YOUR PROGRAM.<br />SEE THE TRUTH.
          </h1>
          <p className="text-xl text-gray-300 mb-8">
            Anonymous athlete-driven ratings for every program.
          </p>
          
          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={onRateProgram}
              className="bg-[#d4af37] hover:bg-[#f4d03f] text-[#001f3f] px-8 py-6 text-lg"
            >
              RATE A PROGRAM
            </Button>
            <Button 
              onClick={onSearchPrograms}
              variant="outline" 
              className="border-2 border-white text-white hover:bg-white/10 px-8 py-6 text-lg"
            >
              SEARCH PROGRAMS
            </Button>
          </div>
        </div>

        {/* Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16">
          <Card className="bg-[#001529] border-[#d4af37]/30 p-8 text-center hover:border-[#d4af37] transition-colors">
            <div className="flex justify-center mb-4">
              <div className="bg-[#003366] p-4 rounded-lg">
                <Star className="size-10 text-[#d4af37]" />
              </div>
            </div>
            <h3 className="text-white mb-2">RATE COACHES<br />& PROGRAMS</h3>
            <p className="text-gray-400 text-sm">
              Share your honest experience and help future athletes make informed decisions
            </p>
          </Card>

          <Card className="bg-[#001529] border-[#d4af37]/30 p-8 text-center hover:border-[#d4af37] transition-colors">
            <div className="flex justify-center mb-4">
              <div className="bg-[#003366] p-4 rounded-lg">
                <MessageSquare className="size-10 text-[#d4af37]" />
              </div>
            </div>
            <h3 className="text-white mb-2">SEE HONEST ATHLETE<br />FEEDBACK</h3>
            <p className="text-gray-400 text-sm">
              Read authentic reviews from current and former student athletes
            </p>
          </Card>

          <Card className="bg-[#001529] border-[#d4af37]/30 p-8 text-center hover:border-[#d4af37] transition-colors">
            <div className="flex justify-center mb-4">
              <div className="bg-[#003366] p-4 rounded-lg">
                <TrendingUp className="size-10 text-[#d4af37]" />
              </div>
            </div>
            <h3 className="text-white mb-2">TRACK TRANSFERS,<br />DEVELOPMENT, AND<br />CULTURE</h3>
            <p className="text-gray-400 text-sm">
              Stay updated on transfer trends and program performance metrics
            </p>
          </Card>
        </div>
      </div>
    </section>
  );
}