import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Star } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface ReviewDialogProps {
  university: any;
  open: boolean;
  onClose: () => void;
}

export function ReviewDialog({ university, open, onClose }: ReviewDialogProps) {
  const [ratings, setRatings] = useState({
    facilities: 0,
    coaching: 0,
    academics: 0,
    athleticProgram: 0
  });
  const [hoveredRating, setHoveredRating] = useState<{ category: string; value: number } | null>(null);
  const [sport, setSport] = useState('');
  const [reviewText, setReviewText] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!sport || !reviewText) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (Object.values(ratings).some(r => r === 0)) {
      toast.error('Please provide ratings for all categories');
      return;
    }

    toast.success('Review submitted successfully!');
    onClose();
    
    // Reset form
    setRatings({ facilities: 0, coaching: 0, academics: 0, athleticProgram: 0 });
    setSport('');
    setReviewText('');
  };

  const RatingInput = ({ 
    category, 
    label 
  }: { 
    category: keyof typeof ratings; 
    label: string;
  }) => {
    const currentRating = hoveredRating?.category === category ? hoveredRating.value : ratings[category];
    
    return (
      <div className="space-y-2">
        <Label>{label}</Label>
        <div className="flex items-center gap-1">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              className="focus:outline-none transition-transform hover:scale-110"
              onClick={() => setRatings(prev => ({ ...prev, [category]: star }))}
              onMouseEnter={() => setHoveredRating({ category, value: star })}
              onMouseLeave={() => setHoveredRating(null)}
            >
              <Star
                className={`size-8 ${
                  star <= currentRating
                    ? 'fill-yellow-400 text-yellow-400'
                    : 'fill-gray-200 text-gray-200'
                }`}
              />
            </button>
          ))}
          <span className="ml-2 text-gray-600">
            {ratings[category] > 0 ? `${ratings[category]}.0` : 'Not rated'}
          </span>
        </div>
      </div>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Write a Review</DialogTitle>
          <DialogDescription>
            {university?.name ? `Share your experience at ${university.name}` : 'Share your student athlete experience'}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 mt-4">
          {/* University Selection (if none selected) */}
          {!university?.name && (
            <div className="space-y-2">
              <Label htmlFor="university">University *</Label>
              <Input id="university" placeholder="Enter university name" required />
            </div>
          )}

          {/* Sport */}
          <div className="space-y-2">
            <Label htmlFor="sport">Your Sport *</Label>
            <Select value={sport} onValueChange={setSport} required>
              <SelectTrigger id="sport">
                <SelectValue placeholder="Select your sport" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Football">Football</SelectItem>
                <SelectItem value="Basketball">Basketball</SelectItem>
                <SelectItem value="Baseball">Baseball</SelectItem>
                <SelectItem value="Softball">Softball</SelectItem>
                <SelectItem value="Soccer">Soccer</SelectItem>
                <SelectItem value="Track & Field">Track & Field</SelectItem>
                <SelectItem value="Swimming">Swimming & Diving</SelectItem>
                <SelectItem value="Volleyball">Volleyball</SelectItem>
                <SelectItem value="Wrestling">Wrestling</SelectItem>
                <SelectItem value="Tennis">Tennis</SelectItem>
                <SelectItem value="Golf">Golf</SelectItem>
                <SelectItem value="Lacrosse">Lacrosse</SelectItem>
                <SelectItem value="Other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Ratings */}
          <div className="space-y-4 p-4 bg-gray-50 rounded-lg">
            <h3 className="text-gray-900">Rate Your Experience</h3>
            <RatingInput category="facilities" label="Athletic Facilities" />
            <RatingInput category="coaching" label="Coaching Staff" />
            <RatingInput category="academics" label="Academic Support" />
            <RatingInput category="athleticProgram" label="Overall Athletic Program" />
          </div>

          {/* Review Text */}
          <div className="space-y-2">
            <Label htmlFor="review">Your Review *</Label>
            <Textarea
              id="review"
              placeholder="Share details about your experience... What did you like? What could be improved? How was the balance between athletics and academics?"
              value={reviewText}
              onChange={(e) => setReviewText(e.target.value)}
              rows={6}
              required
            />
            <p className="text-xs text-gray-500">Minimum 50 characters</p>
          </div>

          {/* Additional Info */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="year">Year Attended</Label>
              <Input id="year" placeholder="e.g., 2023-2024" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="scholarship">Scholarship Status</Label>
              <Select>
                <SelectTrigger id="scholarship">
                  <SelectValue placeholder="Optional" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="full">Full Scholarship</SelectItem>
                  <SelectItem value="partial">Partial Scholarship</SelectItem>
                  <SelectItem value="none">No Scholarship</SelectItem>
                  <SelectItem value="prefer-not">Prefer not to say</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Submit */}
          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button type="submit" className="flex-1">
              Submit Review
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
