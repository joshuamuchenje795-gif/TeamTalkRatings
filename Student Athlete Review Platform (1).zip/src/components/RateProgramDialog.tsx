import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Star } from 'lucide-react';
import { schools, allSports, divisions } from '../data/schools-complete';

interface RateProgramDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function RateProgramDialog({ open, onOpenChange }: RateProgramDialogProps) {
  const [selectedSchool, setSelectedSchool] = useState('');
  const [selectedDivision, setSelectedDivision] = useState('');
  const [selectedSport, setSelectedSport] = useState('');
  const [overallRating, setOverallRating] = useState(0);
  const [facilitiesRating, setFacilitiesRating] = useState(0);
  const [developmentRating, setDevelopmentRating] = useState(0);
  const [cultureRating, setCultureRating] = useState(0);
  const [coachRating, setCoachRating] = useState(0);
  const [reviewTitle, setReviewTitle] = useState('');
  const [reviewText, setReviewText] = useState('');

  const filteredSchools = selectedDivision 
    ? schools.filter(s => s.division === selectedDivision)
    : schools;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedSchool || !selectedSport || overallRating === 0) {
      alert('Please fill in all required fields and provide an overall rating.');
      return;
    }

    // TODO: Implement actual rating submission logic
    const ratingData = {
      school: selectedSchool,
      division: selectedDivision,
      sport: selectedSport,
      ratings: {
        overall: overallRating,
        facilities: facilitiesRating,
        development: developmentRating,
        culture: cultureRating,
        coach: coachRating,
      },
      review: {
        title: reviewTitle,
        text: reviewText,
      },
    };
    
    console.log('Rating submitted:', ratingData);
    alert('Thank you for your rating! This functionality will be implemented with backend.');
    
    // Reset form
    setSelectedSchool('');
    setSelectedDivision('');
    setSelectedSport('');
    setOverallRating(0);
    setFacilitiesRating(0);
    setDevelopmentRating(0);
    setCultureRating(0);
    setCoachRating(0);
    setReviewTitle('');
    setReviewText('');
    onOpenChange(false);
  };

  const StarRating = ({ 
    rating, 
    setRating, 
    label 
  }: { 
    rating: number; 
    setRating: (rating: number) => void; 
    label: string;
  }) => (
    <div className="space-y-2">
      <Label className="text-white">{label}</Label>
      <div className="flex gap-2">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => setRating(star)}
            className="transition-transform hover:scale-110"
          >
            <Star
              className={`size-8 ${
                star <= rating
                  ? 'fill-[#d4af37] text-[#d4af37]'
                  : 'fill-gray-600 text-gray-600'
              }`}
            />
          </button>
        ))}
      </div>
    </div>
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto bg-[#001529] border-[#d4af37]">
        <DialogHeader>
          <DialogTitle className="text-white text-2xl">Rate a Program</DialogTitle>
          <DialogDescription className="text-gray-400">
            Share your experience to help future student athletes make informed decisions.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6 mt-4">
          {/* School Selection */}
          <div className="space-y-2">
            <Label htmlFor="division" className="text-white">Division *</Label>
            <Select value={selectedDivision} onValueChange={setSelectedDivision}>
              <SelectTrigger className="bg-[#001f3f] text-white border-[#d4af37]/50">
                <SelectValue placeholder="Select division" />
              </SelectTrigger>
              <SelectContent>
                {divisions.map((div) => (
                  <SelectItem key={div} value={div}>{div}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="school" className="text-white">School *</Label>
            <Select value={selectedSchool} onValueChange={setSelectedSchool}>
              <SelectTrigger className="bg-[#001f3f] text-white border-[#d4af37]/50">
                <SelectValue placeholder="Select school" />
              </SelectTrigger>
              <SelectContent>
                {filteredSchools.map((school) => (
                  <SelectItem key={school.id} value={school.id}>
                    {school.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="sport" className="text-white">Sport *</Label>
            <Select value={selectedSport} onValueChange={setSelectedSport}>
              <SelectTrigger className="bg-[#001f3f] text-white border-[#d4af37]/50">
                <SelectValue placeholder="Select sport" />
              </SelectTrigger>
              <SelectContent>
                {allSports.map((sport) => (
                  <SelectItem key={sport} value={sport}>{sport}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Ratings */}
          <div className="space-y-4 pt-4 border-t border-[#d4af37]/30">
            <h4 className="text-white">Ratings *</h4>
            
            <StarRating 
              rating={overallRating} 
              setRating={setOverallRating} 
              label="Overall Rating *" 
            />
            
            <StarRating 
              rating={facilitiesRating} 
              setRating={setFacilitiesRating} 
              label="Facilities & Equipment" 
            />
            
            <StarRating 
              rating={developmentRating} 
              setRating={setDevelopmentRating} 
              label="Player Development" 
            />
            
            <StarRating 
              rating={cultureRating} 
              setRating={setCultureRating} 
              label="Team Culture" 
            />
            
            <StarRating 
              rating={coachRating} 
              setRating={setCoachRating} 
              label="Coaching Staff" 
            />
          </div>

          {/* Review */}
          <div className="space-y-4 pt-4 border-t border-[#d4af37]/30">
            <h4 className="text-white">Your Review (Optional)</h4>
            
            <div className="space-y-2">
              <Label htmlFor="review-title" className="text-white">Review Title</Label>
              <Input
                id="review-title"
                type="text"
                placeholder="Sum up your experience in one line"
                value={reviewTitle}
                onChange={(e) => setReviewTitle(e.target.value)}
                className="bg-[#001f3f] text-white border-[#d4af37]/50"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="review-text" className="text-white">Detailed Review</Label>
              <Textarea
                id="review-text"
                placeholder="Share your experience with facilities, coaching, culture, and overall program quality..."
                value={reviewText}
                onChange={(e) => setReviewText(e.target.value)}
                rows={5}
                className="bg-[#001f3f] text-white border-[#d4af37]/50"
              />
            </div>
          </div>

          <div className="flex gap-4 pt-4">
            <Button
              type="button"
              variant="outline"
              className="flex-1 border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37]/10"
              onClick={() => onOpenChange(false)}
            >
              CANCEL
            </Button>
            <Button 
              type="submit" 
              className="flex-1 bg-[#d4af37] text-[#001f3f] hover:bg-[#f4d03f]"
            >
              SUBMIT RATING
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}