import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { UniversityCard } from './UniversityCard';
import { ReviewDialog } from './ReviewDialog';
import { Search, Filter } from 'lucide-react';

const mockUniversities = [
  {
    id: 1,
    name: 'University of Southern California',
    division: 'NCAA Division I',
    conference: 'Big Ten',
    location: 'Los Angeles, CA',
    overallRating: 4.7,
    facilitiesRating: 4.8,
    coachingRating: 4.6,
    academicsRating: 4.5,
    athleticProgramRating: 4.9,
    reviewCount: 247,
    sports: ['Football', 'Basketball', 'Track & Field', 'Swimming']
  },
  {
    id: 2,
    name: 'Duke University',
    division: 'NCAA Division I',
    conference: 'ACC',
    location: 'Durham, NC',
    overallRating: 4.8,
    facilitiesRating: 4.7,
    coachingRating: 4.9,
    academicsRating: 4.9,
    athleticProgramRating: 4.7,
    reviewCount: 189,
    sports: ['Basketball', 'Lacrosse', 'Soccer', 'Golf']
  },
  {
    id: 3,
    name: 'University of Texas',
    division: 'NCAA Division I',
    conference: 'SEC',
    location: 'Austin, TX',
    overallRating: 4.6,
    facilitiesRating: 4.8,
    coachingRating: 4.5,
    academicsRating: 4.4,
    athleticProgramRating: 4.7,
    reviewCount: 312,
    sports: ['Football', 'Baseball', 'Swimming', 'Volleyball']
  },
  {
    id: 4,
    name: 'Santa Monica College',
    division: 'NJCAA Division I',
    conference: 'Western State Conference',
    location: 'Santa Monica, CA',
    overallRating: 4.3,
    facilitiesRating: 4.2,
    coachingRating: 4.4,
    academicsRating: 4.1,
    athleticProgramRating: 4.3,
    reviewCount: 98,
    sports: ['Football', 'Basketball', 'Track & Field', 'Soccer']
  },
  {
    id: 5,
    name: 'Grand View University',
    division: 'NAIA',
    conference: 'Heart of America',
    location: 'Des Moines, IA',
    overallRating: 4.4,
    facilitiesRating: 4.3,
    coachingRating: 4.5,
    academicsRating: 4.2,
    athleticProgramRating: 4.4,
    reviewCount: 76,
    sports: ['Wrestling', 'Football', 'Track & Field', 'Basketball']
  },
  {
    id: 6,
    name: 'Stanford University',
    division: 'NCAA Division I',
    conference: 'ACC',
    location: 'Stanford, CA',
    overallRating: 4.9,
    facilitiesRating: 4.9,
    coachingRating: 4.8,
    academicsRating: 5.0,
    athleticProgramRating: 4.8,
    reviewCount: 203,
    sports: ['Swimming', 'Tennis', 'Volleyball', 'Soccer']
  }
];

export function UniversityRatings() {
  const [searchQuery, setSearchQuery] = useState('');
  const [divisionFilter, setDivisionFilter] = useState('all');
  const [sportFilter, setSportFilter] = useState('all');
  const [selectedUniversity, setSelectedUniversity] = useState<typeof mockUniversities[0] | null>(null);

  const filteredUniversities = mockUniversities.filter(uni => {
    const matchesSearch = uni.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         uni.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDivision = divisionFilter === 'all' || uni.division === divisionFilter;
    const matchesSport = sportFilter === 'all' || uni.sports.includes(sportFilter);
    
    return matchesSearch && matchesDivision && matchesSport;
  });

  return (
    <div className="space-y-6">
      {/* Filters */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <Filter className="size-5 text-gray-600" />
          <h2 className="text-gray-900">Search & Filter</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
            <Input
              placeholder="Search universities or location..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Select value={divisionFilter} onValueChange={setDivisionFilter}>
            <SelectTrigger>
              <SelectValue placeholder="All Divisions" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Divisions</SelectItem>
              <SelectItem value="NCAA Division I">NCAA Division I</SelectItem>
              <SelectItem value="NCAA Division II">NCAA Division II</SelectItem>
              <SelectItem value="NCAA Division III">NCAA Division III</SelectItem>
              <SelectItem value="NJCAA Division I">NJCAA Division I</SelectItem>
              <SelectItem value="NJCAA Division II">NJCAA Division II</SelectItem>
              <SelectItem value="NJCAA Division III">NJCAA Division III</SelectItem>
              <SelectItem value="NAIA">NAIA</SelectItem>
            </SelectContent>
          </Select>

          <Select value={sportFilter} onValueChange={setSportFilter}>
            <SelectTrigger>
              <SelectValue placeholder="All Sports" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Sports</SelectItem>
              <SelectItem value="Football">Football</SelectItem>
              <SelectItem value="Basketball">Basketball</SelectItem>
              <SelectItem value="Baseball">Baseball</SelectItem>
              <SelectItem value="Soccer">Soccer</SelectItem>
              <SelectItem value="Track & Field">Track & Field</SelectItem>
              <SelectItem value="Swimming">Swimming</SelectItem>
              <SelectItem value="Volleyball">Volleyball</SelectItem>
              <SelectItem value="Wrestling">Wrestling</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Results Count */}
      <div className="flex items-center justify-between">
        <p className="text-gray-600">
          Showing {filteredUniversities.length} {filteredUniversities.length === 1 ? 'university' : 'universities'}
        </p>
        <Button onClick={() => setSelectedUniversity({} as any)}>
          Write a Review
        </Button>
      </div>

      {/* University Cards */}
      <div className="grid gap-6">
        {filteredUniversities.map(university => (
          <UniversityCard
            key={university.id}
            university={university}
            onWriteReview={() => setSelectedUniversity(university)}
          />
        ))}
      </div>

      {filteredUniversities.length === 0 && (
        <Card className="p-12 text-center">
          <p className="text-gray-600">No universities found matching your criteria.</p>
          <Button
            variant="outline"
            className="mt-4"
            onClick={() => {
              setSearchQuery('');
              setDivisionFilter('all');
              setSportFilter('all');
            }}
          >
            Clear Filters
          </Button>
        </Card>
      )}

      <ReviewDialog
        university={selectedUniversity}
        open={selectedUniversity !== null}
        onClose={() => setSelectedUniversity(null)}
      />
    </div>
  );
}
