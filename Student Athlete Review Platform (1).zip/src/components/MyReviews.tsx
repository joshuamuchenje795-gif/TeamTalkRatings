import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Star, Calendar, ThumbsUp, MessageSquare, Edit, Trash2 } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';

const myReviews = [
  {
    id: 1,
    universityName: 'University of Southern California',
    sport: 'Football',
    date: '2024-10-15',
    ratings: {
      facilities: 5,
      coaching: 4,
      academics: 4,
      athleticProgram: 5
    },
    reviewText: 'Amazing facilities and top-notch coaching staff. The weight room and training facilities are some of the best in the country. Academic support is strong with dedicated tutors for athletes. The only downside is the demanding schedule, but thats expected at this level.',
    likes: 23,
    comments: 5,
    verified: true
  },
  {
    id: 2,
    universityName: 'Santa Monica College',
    sport: 'Track & Field',
    date: '2024-09-22',
    ratings: {
      facilities: 4,
      coaching: 5,
      academics: 4,
      athleticProgram: 4
    },
    reviewText: 'Great stepping stone for transferring to a four-year program. Coach Williams is incredibly supportive and helped me improve my times significantly. The track is well-maintained and we have access to good training equipment. Perfect for athletes looking to develop before moving to D1.',
    likes: 15,
    comments: 3,
    verified: true
  }
];

export function MyReviews() {
  const [reviews, setReviews] = useState(myReviews);

  const calculateOverallRating = (ratings: any) => {
    const values = Object.values(ratings) as number[];
    return (values.reduce((a: number, b: number) => a + b, 0) / values.length).toFixed(1);
  };

  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`size-4 ${
              star <= rating
                ? 'fill-yellow-400 text-yellow-400'
                : 'fill-gray-200 text-gray-200'
            }`}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-gray-900 mb-1">Your Reviews</h2>
            <p className="text-gray-600">You have written {reviews.length} reviews</p>
          </div>
          <Button>Write New Review</Button>
        </div>
      </Card>

      {/* Info Alert */}
      <Alert>
        <AlertDescription>
          Your reviews help other student athletes make informed decisions. Thank you for contributing to the community!
        </AlertDescription>
      </Alert>

      {/* Reviews */}
      {reviews.length > 0 ? (
        <div className="space-y-4">
          {reviews.map(review => (
            <Card key={review.id} className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-[#001f3f]">{review.universityName}</h3>
                    {review.verified && (
                      <Badge className="bg-[#d4af37] text-[#001f3f] hover:bg-[#b8941e]">
                        Verified Athlete
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <Badge variant="secondary" className="bg-[#001f3f] text-white hover:bg-[#003366]">{review.sport}</Badge>
                    <div className="flex items-center gap-1">
                      <Calendar className="size-4" />
                      {new Date(review.date).toLocaleDateString()}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="sm">
                    <Edit className="size-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Trash2 className="size-4 text-red-600" />
                  </Button>
                </div>
              </div>

              {/* Overall Rating */}
              <div className="flex items-center gap-4 mb-4 p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-2">
                  <Star className="size-6 fill-yellow-400 text-yellow-400" />
                  <span className="text-gray-900">
                    {calculateOverallRating(review.ratings)}
                  </span>
                </div>
                <div className="h-8 w-px bg-gray-300" />
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 flex-1">
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Facilities</p>
                    {renderStars(review.ratings.facilities)}
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Coaching</p>
                    {renderStars(review.ratings.coaching)}
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Academics</p>
                    {renderStars(review.ratings.academics)}
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Program</p>
                    {renderStars(review.ratings.athleticProgram)}
                  </div>
                </div>
              </div>

              {/* Review Text */}
              <p className="text-gray-700 mb-4 leading-relaxed">
                {review.reviewText}
              </p>

              {/* Engagement */}
              <div className="flex items-center gap-6 pt-4 border-t border-gray-200">
                <button className="flex items-center gap-2 text-gray-600 hover:text-blue-600 transition-colors">
                  <ThumbsUp className="size-4" />
                  <span className="text-sm">{review.likes} helpful</span>
                </button>
                <button className="flex items-center gap-2 text-gray-600 hover:text-blue-600 transition-colors">
                  <MessageSquare className="size-4" />
                  <span className="text-sm">{review.comments} comments</span>
                </button>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="p-12 text-center">
          <p className="text-gray-600 mb-4">You haven't written any reviews yet.</p>
          <Button>Write Your First Review</Button>
        </Card>
      )}
    </div>
  );
}