import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Star, Shield } from 'lucide-react';
import { Progress } from './ui/progress';

const trendingPrograms = [
  {
    id: 1,
    name: 'University of Southern California',
    sport: 'Football',
    division: 'NCAA D1',
    overallRating: 4.5,
    facilities: 92,
    development: 88,
    culture: 85,
    reviews: 247
  },
  {
    id: 2,
    name: 'Duke University',
    sport: 'Basketball',
    division: 'NCAA D1',
    overallRating: 4.5,
    facilities: 90,
    development: 93,
    culture: 89,
    reviews: 189
  },
  {
    id: 3,
    name: 'Stanford University',
    sport: 'Swimming',
    division: 'NCAA D1',
    overallRating: 4.5,
    facilities: 95,
    development: 91,
    culture: 87,
    reviews: 203
  },
  {
    id: 4,
    name: 'University of Texas',
    sport: 'Track & Field',
    division: 'NCAA D1',
    overallRating: 4.5,
    facilities: 88,
    development: 86,
    culture: 90,
    reviews: 312
  }
];

export function TrendingPrograms() {
  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`size-5 ${
              star <= rating
                ? 'fill-[#d4af37] text-[#d4af37]'
                : 'fill-gray-600 text-gray-600'
            }`}
          />
        ))}
      </div>
    );
  };

  return (
    <section className="bg-[#001f3f] py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-white mb-8">TRENDING PROGRAMS</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {trendingPrograms.map((program) => (
            <Card 
              key={program.id} 
              className="bg-[#001529] border-[#d4af37]/30 overflow-hidden hover:border-[#d4af37] transition-all hover:shadow-lg hover:shadow-[#d4af37]/20"
            >
              <div className="p-6">
                {/* Shield Icon */}
                <div className="flex justify-center mb-4">
                  <div className="bg-gradient-to-b from-[#0066cc] to-[#003d99] p-6 rounded-lg">
                    <Shield className="size-12 text-white" />
                  </div>
                </div>

                {/* Rating */}
                <div className="flex items-center justify-center gap-2 mb-4">
                  {renderStars(program.overallRating)}
                  <span className="text-white ml-2">{program.overallRating}</span>
                </div>

                {/* Metrics */}
                <div className="space-y-3 mb-6">
                  <div>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="text-gray-400">FACILITIES</span>
                    </div>
                    <Progress 
                      value={program.facilities} 
                      className="h-2 bg-gray-700"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="text-gray-400">DEVELOPMENT</span>
                    </div>
                    <Progress 
                      value={program.development} 
                      className="h-2 bg-gray-700"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="text-gray-400">CULTURE</span>
                    </div>
                    <Progress 
                      value={program.culture} 
                      className="h-2 bg-gray-700"
                    />
                  </div>
                </div>

                {/* View Profile Button */}
                <Button 
                  variant="outline" 
                  className="w-full border-white text-white hover:bg-white/10"
                >
                  VIEW PROGRAM PROFILE
                </Button>

                {/* Program Info */}
                <div className="mt-4 pt-4 border-t border-gray-700">
                  <p className="text-white text-sm mb-1">{program.name}</p>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="bg-[#003366] text-[#d4af37] text-xs">
                      {program.sport}
                    </Badge>
                    <span className="text-gray-400 text-xs">• {program.reviews} reviews</span>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* View More */}
        <div className="text-center mt-8">
          <Button 
            variant="outline" 
            className="border-2 border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37] hover:text-[#001f3f]"
          >
            VIEW MORE PROGRAMS
          </Button>
        </div>
      </div>
    </section>
  );
}
