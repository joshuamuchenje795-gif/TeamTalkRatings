import { useState } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { TrendingUp, ArrowRight, Calendar, Users, BarChart3 } from 'lucide-react';

const transferNews = [
  {
    id: 1,
    athleteName: 'Marcus Johnson',
    sport: 'Football',
    position: 'QB',
    fromSchool: 'Ohio State University',
    toSchool: 'University of Miami',
    fromDivision: 'NCAA Division I',
    toDivision: 'NCAA Division I',
    date: '2024-11-15',
    reason: 'Playing time',
    trending: true
  },
  {
    id: 2,
    athleteName: 'Sarah Williams',
    sport: 'Basketball',
    position: 'Guard',
    fromSchool: 'UConn',
    toSchool: 'South Carolina',
    fromDivision: 'NCAA Division I',
    toDivision: 'NCAA Division I',
    date: '2024-11-14',
    reason: 'Coaching change',
    trending: true
  },
  {
    id: 3,
    athleteName: 'David Chen',
    sport: 'Baseball',
    position: 'Pitcher',
    fromSchool: 'Santa Monica College',
    toSchool: 'UCLA',
    fromDivision: 'NJCAA Division I',
    toDivision: 'NCAA Division I',
    date: '2024-11-13',
    reason: 'Academic advancement',
    trending: false
  },
  {
    id: 4,
    athleteName: 'Emily Rodriguez',
    sport: 'Soccer',
    position: 'Forward',
    fromSchool: 'Stanford University',
    toSchool: 'University of North Carolina',
    fromDivision: 'NCAA Division I',
    toDivision: 'NCAA Division I',
    date: '2024-11-12',
    reason: 'Better program fit',
    trending: true
  },
  {
    id: 5,
    athleteName: 'Tyler Brown',
    sport: 'Track & Field',
    position: '400m',
    fromSchool: 'Iowa Central CC',
    toSchool: 'University of Oregon',
    fromDivision: 'NJCAA Division I',
    toDivision: 'NCAA Division I',
    date: '2024-11-10',
    reason: 'Scholarship offer',
    trending: false
  }
];

const transferTrends = [
  { 
    trend: 'NJCAA to NCAA D1 transfers',
    count: 1247,
    change: '+18%',
    sport: 'All Sports',
    description: 'Strong increase in junior college transfers to Division I programs'
  },
  {
    trend: 'Portal entries from Power 5',
    count: 892,
    change: '+23%',
    sport: 'Football',
    description: 'Record number of players entering transfer portal from major conferences'
  },
  {
    trend: 'Graduate transfers',
    count: 654,
    change: '+12%',
    sport: 'All Sports',
    description: 'More athletes utilizing fifth year eligibility at different schools'
  },
  {
    trend: 'Basketball transfers',
    count: 543,
    change: '+15%',
    sport: 'Basketball',
    description: 'Increased mobility in both mens and womens basketball'
  }
];

export function TransferNews() {
  const [sportFilter, setSportFilter] = useState('all');

  const filteredNews = sportFilter === 'all' 
    ? transferNews 
    : transferNews.filter(item => item.sport === sportFilter);

  return (
    <div className="space-y-6">
      <Tabs defaultValue="news" className="w-full">
        <TabsList className="grid w-full max-w-md mx-auto grid-cols-2">
          <TabsTrigger value="news">Latest Transfers</TabsTrigger>
          <TabsTrigger value="trends">Transfer Trends</TabsTrigger>
        </TabsList>

        <TabsContent value="news" className="space-y-6 mt-6">
          {/* Filter */}
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <h2 className="text-gray-900">Filter by Sport</h2>
              <Select value={sportFilter} onValueChange={setSportFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="All Sports" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Sports</SelectItem>
                  <SelectItem value="Football">Football</SelectItem>
                  <SelectItem value="Basketball">Basketball</SelectItem>
                  <SelectItem value="Baseball">Baseball</SelectItem>
                  <SelectItem value="Soccer">Soccer</SelectItem>
                  <SelectItem value="Track & Field">Track & Field</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </Card>

          {/* News Items */}
          <div className="space-y-4">
            {filteredNews.map(item => (
              <Card key={item.id} className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="bg-gradient-to-br from-[#001f3f] to-[#003366] text-white size-12 rounded-full flex items-center justify-center">
                      {item.athleteName.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div>
                      <h3 className="text-[#001f3f]">{item.athleteName}</h3>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Badge variant="secondary" className="bg-[#001f3f] text-white hover:bg-[#003366]">{item.sport}</Badge>
                        <span>•</span>
                        <span>{item.position}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {item.trending && (
                      <Badge className="bg-[#d4af37] hover:bg-[#b8941e] text-[#001f3f]">
                        <TrendingUp className="size-3 mr-1" />
                        Trending
                      </Badge>
                    )}
                    <div className="flex items-center text-sm text-gray-500">
                      <Calendar className="size-4 mr-1" />
                      {new Date(item.date).toLocaleDateString()}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 mb-4 p-4 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <p className="text-sm text-gray-500 mb-1">From</p>
                    <p className="text-gray-900">{item.fromSchool}</p>
                    <p className="text-xs text-gray-600">{item.fromDivision}</p>
                  </div>
                  
                  <ArrowRight className="size-6 text-gray-400 flex-shrink-0" />
                  
                  <div className="flex-1">
                    <p className="text-sm text-gray-500 mb-1">To</p>
                    <p className="text-gray-900">{item.toSchool}</p>
                    <p className="text-xs text-gray-600">{item.toDivision}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="text-sm text-gray-600">
                    <span className="text-gray-500">Reason:</span> {item.reason}
                  </div>
                  <Button variant="outline" size="sm">
                    View Details
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="trends" className="space-y-6 mt-6">
          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="p-6 border-l-4 border-l-[#001f3f]">
              <div className="flex items-center justify-between mb-2">
                <Users className="size-8 text-[#001f3f]" />
                <span className="text-green-600">+15.3%</span>
              </div>
              <p className="text-[#001f3f]">3,456</p>
              <p className="text-sm text-gray-600">Total Transfers This Season</p>
            </Card>

            <Card className="p-6 border-l-4 border-l-[#d4af37]">
              <div className="flex items-center justify-between mb-2">
                <TrendingUp className="size-8 text-[#d4af37]" />
                <span className="text-green-600">+8.2%</span>
              </div>
              <p className="text-[#001f3f]">1,234</p>
              <p className="text-sm text-gray-600">Division Upgrades</p>
            </Card>

            <Card className="p-6 border-l-4 border-l-[#001f3f]">
              <div className="flex items-center justify-between mb-2">
                <BarChart3 className="size-8 text-[#001f3f]" />
                <span className="text-[#d4af37]">New High</span>
              </div>
              <p className="text-[#001f3f]">892</p>
              <p className="text-sm text-gray-600">Portal Entries This Week</p>
            </Card>
          </div>

          {/* Trend Cards */}
          <div className="space-y-4">
            <h2 className="text-gray-900">Key Transfer Trends</h2>
            {transferTrends.map((trend, index) => (
              <Card key={index} className="p-6">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-gray-900">{trend.trend}</h3>
                      <Badge 
                        className={
                          trend.change.startsWith('+') 
                            ? 'bg-green-100 text-green-700 hover:bg-green-200' 
                            : 'bg-red-100 text-red-700 hover:bg-red-200'
                        }
                      >
                        {trend.change}
                      </Badge>
                    </div>
                    <p className="text-gray-600 mb-2">{trend.description}</p>
                    <Badge variant="outline">{trend.sport}</Badge>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-gray-900 mb-1">{trend.count}</p>
                    <p className="text-xs text-gray-500">athletes</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}