// This file contains the complete list of all NCAA D1, D2, D3, NAIA, and NJCAA schools
export interface School {
  id: string;
  name: string;
  division: 'NCAA D1' | 'NCAA D2' | 'NCAA D3' | 'NAIA' | 'NJCAA D1' | 'NJCAA D2' | 'NJCAA D3';
  state: string;
  sports: string[];
  overallRating?: number;
  totalReviews?: number;
}

// Helper function to generate school ID from name
const generateId = (name: string): string => {
  return name.toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/--+/g, '-');
};

// Common sports by division
const D1_SPORTS = ['Football', 'Basketball', 'Baseball', 'Soccer', 'Track & Field', 'Swimming', 'Volleyball', 'Softball', 'Tennis', 'Golf'];
const D2_SPORTS = ['Football', 'Basketball', 'Baseball', 'Soccer', 'Volleyball', 'Softball', 'Track & Field', 'Cross Country'];
const D3_SPORTS = ['Basketball', 'Soccer', 'Baseball', 'Softball', 'Track & Field', 'Swimming', 'Volleyball', 'Lacrosse'];
const NAIA_SPORTS = ['Basketball', 'Baseball', 'Soccer', 'Track & Field', 'Volleyball', 'Softball', 'Cross Country'];
const NJCAA_SPORTS = ['Basketball', 'Baseball', 'Softball', 'Soccer', 'Volleyball', 'Track & Field'];

// State mapping for schools (simplified - you can expand this)
const stateMap: { [key: string]: string } = {
  'Alabama': 'Alabama', 'Alabama A&M': 'Alabama', 'Alabama State': 'Alabama', 'Auburn': 'Alabama',
  'Alaska': 'Alaska', 'Anchorage': 'Alaska',
  'Arizona': 'Arizona', 'Arizona State': 'Arizona', 'Grand Canyon': 'Arizona', 'Northern Arizona': 'Arizona',
  'Arkansas': 'Arkansas', 'Arkansas State': 'Arkansas', 'Central Arkansas': 'Arkansas',
  'California': 'California', 'UCLA': 'California', 'USC': 'California', 'Stanford': 'California',
  'Colorado': 'Colorado', 'Colorado State': 'Colorado', 'Air Force': 'Colorado',
  'Connecticut': 'Connecticut', 'UConn': 'Connecticut', 'Yale': 'Connecticut',
  'Delaware': 'Delaware',
  'Florida': 'Florida', 'Florida State': 'Florida', 'Miami (FL)': 'Florida', 'UCF': 'Florida',
  'Georgia': 'Georgia', 'Georgia Tech': 'Georgia', 'Georgia State': 'Georgia',
  'Hawaii': 'Hawaii',
  'Idaho': 'Idaho', 'Idaho State': 'Idaho', 'Boise State': 'Idaho',
  'Illinois': 'Illinois', 'Northwestern': 'Illinois', 'DePaul': 'Illinois',
  'Indiana': 'Indiana', 'Purdue': 'Indiana', 'Notre Dame': 'Indiana',
  'Iowa': 'Iowa', 'Iowa State': 'Iowa',
  'Kansas': 'Kansas', 'Kansas State': 'Kansas', 'Wichita State': 'Kansas',
  'Kentucky': 'Kentucky', 'Louisville': 'Kentucky',
  'Louisiana': 'Louisiana', 'LSU': 'Louisiana', 'Tulane': 'Louisiana',
  'Maine': 'Maine',
  'Maryland': 'Maryland', 'Navy': 'Maryland',
  'Massachusetts': 'Massachusetts', 'Boston College': 'Massachusetts', 'Boston University': 'Massachusetts',
  'Michigan': 'Michigan', 'Michigan State': 'Michigan',
  'Minnesota': 'Minnesota',
  'Mississippi': 'Mississippi', 'Mississippi State': 'Mississippi', 'Ole Miss': 'Mississippi',
  'Missouri': 'Missouri', 'Missouri State': 'Missouri',
  'Montana': 'Montana', 'Montana State': 'Montana',
  'Nebraska': 'Nebraska',
  'Nevada': 'Nevada', 'UNLV': 'Nevada',
  'New Hampshire': 'New Hampshire',
  'New Jersey': 'New Jersey', 'Rutgers': 'New Jersey', 'Princeton': 'New Jersey',
  'New Mexico': 'New Mexico', 'New Mexico State': 'New Mexico',
  'New York': 'New York', 'Syracuse': 'New York', 'Cornell': 'New York', 'Columbia': 'New York',
  'North Carolina': 'North Carolina', 'Duke': 'North Carolina', 'Wake Forest': 'North Carolina',
  'North Dakota': 'North Dakota', 'North Dakota State': 'North Dakota',
  'Ohio': 'Ohio', 'Ohio State': 'Ohio', 'Cincinnati': 'Ohio',
  'Oklahoma': 'Oklahoma', 'Oklahoma State': 'Oklahoma',
  'Oregon': 'Oregon', 'Oregon State': 'Oregon',
  'Pennsylvania': 'Pennsylvania', 'Penn State': 'Pennsylvania', 'Pittsburgh': 'Pennsylvania',
  'Rhode Island': 'Rhode Island',
  'South Carolina': 'South Carolina', 'Clemson': 'South Carolina',
  'South Dakota': 'South Dakota', 'South Dakota State': 'South Dakota',
  'Tennessee': 'Tennessee', 'Vanderbilt': 'Tennessee', 'Memphis': 'Tennessee',
  'Texas': 'Texas', 'Texas A&M': 'Texas', 'TCU': 'Texas', 'Baylor': 'Texas',
  'Utah': 'Utah', 'Utah State': 'Utah', 'BYU': 'Utah',
  'Vermont': 'Vermont',
  'Virginia': 'Virginia', 'Virginia Tech': 'Virginia',
  'Washington': 'Washington', 'Washington State': 'Washington',
  'West Virginia': 'West Virginia',
  'Wisconsin': 'Wisconsin',
  'Wyoming': 'Wyoming'
};

const getState = (schoolName: string): string => {
  // Direct match
  if (stateMap[schoolName]) return stateMap[schoolName];
  
  // Check if school name contains state name
  for (const [key, value] of Object.entries(stateMap)) {
    if (schoolName.includes(key)) return value;
  }
  
  // Parse state abbreviations and common patterns
  if (schoolName.includes('(PA)')) return 'Pennsylvania';
  if (schoolName.includes('(OH)')) return 'Ohio';
  if (schoolName.includes('(FL)')) return 'Florida';
  if (schoolName.includes('(CA)')) return 'California';
  if (schoolName.includes('(TX)')) return 'Texas';
  if (schoolName.includes('(IL)')) return 'Illinois';
  if (schoolName.includes('(IN)')) return 'Indiana';
  if (schoolName.includes('(MI)')) return 'Michigan';
  if (schoolName.includes('(NY)')) return 'New York';
  if (schoolName.includes('(MA)')) return 'Massachusetts';
  if (schoolName.includes('(NC)')) return 'North Carolina';
  if (schoolName.includes('(SC)')) return 'South Carolina';
  if (schoolName.includes('(VA)')) return 'Virginia';
  if (schoolName.includes('(WV)')) return 'West Virginia';
  if (schoolName.includes('(TN)')) return 'Tennessee';
  if (schoolName.includes('(KY)')) return 'Kentucky';
  if (schoolName.includes('(MO)')) return 'Missouri';
  if (schoolName.includes('(KS)')) return 'Kansas';
  if (schoolName.includes('(NE)')) return 'Nebraska';
  if (schoolName.includes('(IA)')) return 'Iowa';
  if (schoolName.includes('(MN)')) return 'Minnesota';
  if (schoolName.includes('(WI)')) return 'Wisconsin';
  if (schoolName.includes('(SD)')) return 'South Dakota';
  if (schoolName.includes('(ND)')) return 'North Dakota';
  if (schoolName.includes('(MT)')) return 'Montana';
  if (schoolName.includes('(WA)')) return 'Washington';
  if (schoolName.includes('(OR)')) return 'Oregon';
  if (schoolName.includes('(AZ)')) return 'Arizona';
  if (schoolName.includes('(NM)')) return 'New Mexico';
  if (schoolName.includes('(CO)')) return 'Colorado';
  if (schoolName.includes('(WY)')) return 'Wyoming';
  if (schoolName.includes('(LA)')) return 'Louisiana';
  if (schoolName.includes('(MS)')) return 'Mississippi';
  if (schoolName.includes('(AL)')) return 'Alabama';
  if (schoolName.includes('(GA)')) return 'Georgia';
  if (schoolName.includes('(AR)')) return 'Arkansas';
  if (schoolName.includes('(OK)')) return 'Oklahoma';
  if (schoolName.includes('(RI)')) return 'Rhode Island';
  if (schoolName.includes('(CT)')) return 'Connecticut';
  if (schoolName.includes('(VT)')) return 'Vermont';
  if (schoolName.includes('(NH)')) return 'New Hampshire';
  if (schoolName.includes('(ME)')) return 'Maine';
  if (schoolName.includes('(DE)')) return 'Delaware';
  if (schoolName.includes('(MD)')) return 'Maryland';
  if (schoolName.includes('(NJ)')) return 'New Jersey';
  
  // Default
  return 'United States';
};

// NCAA Division I Schools
const ncaaD1Schools = [
  "Abilene Christian", "Air Force", "Akron", "Alabama", "Alabama A&M", "Alabama State",
  "Albany", "Alcorn State", "American", "Appalachian State", "Arizona", "Arizona State",
  "Arkansas", "Arkansas State", "Arkansas–Pine Bluff", "Army", "Auburn", "Austin Peay",
  "Ball State", "Baylor", "Bellarmine", "Belmont", "Bethune–Cookman", "Binghamton",
  "Boise State", "Boston College", "Boston University", "Bowling Green", "Bradley",
  "Brigham Young", "Brown", "Bryant", "Bucknell", "Buffalo", "Butler", "Cal Baptist",
  "Cal Poly", "Cal State Bakersfield", "Cal State Fullerton", "Cal State Northridge",
  "California", "Campbell", "Canisius", "Central Arkansas", "Central Connecticut State",
  "Central Michigan", "Charleston Southern", "Charlotte", "Chattanooga", "Chicago State",
  "Cincinnati", "Clemson", "Cleveland State", "Coastal Carolina", "Colgate",
  "College of Charleston", "Colorado", "Colorado State", "Columbia", "Coppin State",
  "Cornell", "Creighton", "Dartmouth", "Davidson", "Dayton", "Delaware", "Delaware State",
  "Denver", "DePaul", "Detroit Mercy", "Drake", "Drexel", "Duke", "Duquesne",
  "East Carolina", "East Tennessee State", "Eastern Illinois", "Eastern Kentucky",
  "Eastern Michigan", "Eastern Washington", "Elon", "Evansville", "Fairfield",
  "Fairleigh Dickinson", "Florida", "Florida A&M", "Florida Atlantic", "Florida Gulf Coast",
  "Florida International", "Florida State", "Fordham", "Fresno State", "Furman",
  "Gardner–Webb", "George Mason", "George Washington", "Georgetown", "Georgia",
  "Georgia Southern", "Georgia State", "Georgia Tech", "Gonzaga", "Grambling State",
  "Grand Canyon", "Green Bay", "Hampton", "Harvard", "Hawaii", "High Point", "Hofstra",
  "Holy Cross", "Houston", "Houston Christian", "Howard", "Idaho", "Idaho State",
  "Illinois", "Illinois State", "Illinois–Chicago", "Incarnate Word", "Indiana",
  "Indiana State", "Iona", "Iowa", "Iowa State", "IUPUI", "Jackson State", "Jacksonville",
  "Jacksonville State", "James Madison", "Kansas", "Kansas State", "Kennesaw State",
  "Kent State", "Kentucky", "La Salle", "Lafayette", "Lamar", "Lehigh", "Liberty",
  "Lipscomb", "Long Beach State", "Long Island University", "Longwood", "Louisiana",
  "Louisiana Tech", "Louisiana–Monroe", "Louisiana–Lafayette", "Louisville", "Loyola Chicago",
  "Loyola Marymount", "Maine", "Manhattan", "Marist", "Marquette", "Marshall", "Maryland",
  "Maryland–Eastern Shore", "Massachusetts", "Massachusetts–Lowell", "McNeese State",
  "Memphis", "Mercer", "Merrimack", "Miami (FL)", "Miami (OH)", "Michigan", "Michigan State",
  "Middle Tennessee", "Milwaukee", "Minnesota", "Mississippi State", "Mississippi Valley State",
  "Missouri", "Missouri State", "Monmouth", "Montana", "Montana State", "Morehead State",
  "Morgan State", "Mount St. Mary's", "Murray State", "Navy", "Nebraska", "Nevada",
  "New Hampshire", "New Mexico", "New Mexico State", "New Orleans", "Niagara",
  "Nicholls State", "Norfolk State", "North Alabama", "North Carolina", "North Carolina A&T",
  "North Carolina Central", "North Carolina State", "North Dakota", "North Dakota State",
  "North Florida", "North Texas", "Northern Arizona", "Northern Colorado", "Northern Illinois",
  "Northern Iowa", "Northern Kentucky", "Northwestern", "Northwestern State", "Notre Dame",
  "Oakland", "Ohio", "Ohio State", "Oklahoma", "Oklahoma State", "Old Dominion", "Ole Miss",
  "Omaha", "Oral Roberts", "Oregon", "Oregon State", "Pacific", "Penn State", "Pennsylvania",
  "Pepperdine", "Pittsburgh", "Portland", "Portland State", "Prairie View A&M", "Presbyterian",
  "Princeton", "Providence", "Purdue", "Quinnipiac", "Radford", "Rhode Island", "Rice",
  "Richmond", "Rider", "Robert Morris", "Rutgers", "Sacramento State", "Sacred Heart",
  "Saint Francis (PA)", "Saint Joseph's", "Saint Louis", "Saint Mary's", "Sam Houston",
  "Samford", "San Diego", "San Diego State", "San Francisco", "San Jose State", "Santa Clara",
  "Seattle", "Seton Hall", "Siena", "South Alabama", "South Carolina", "South Carolina State",
  "South Dakota", "South Dakota State", "South Florida", "Southeast Missouri State",
  "Southeastern Louisiana", "Southern", "Southern Illinois", "Southern Illinois–Edwardsville",
  "Southern Miss", "Southern Utah", "Stanford", "Stetson", "Stony Brook", "Syracuse",
  "Tarleton State", "TCU", "Temple", "Tennessee", "Tennessee State", "Tennessee Tech",
  "Texas", "Texas A&M", "Texas A&M–Corpus Christi", "Texas State", "Texas Tech",
  "Texas–Arlington", "Texas–El Paso", "Texas–Rio Grande Valley", "Texas–San Antonio",
  "Toledo", "Towson", "Troy", "Tulane", "Tulsa", "UC Davis", "UC Irvine", "UC Riverside",
  "UC San Diego", "UC Santa Barbara", "UCF", "UConn", "UIC", "UCLA", "UMBC", "UNLV", "USC",
  "Utah", "Utah State", "Utah Tech", "Utah Valley", "UTEP", "UTSA", "Valparaiso",
  "Vanderbilt", "Vermont", "Villanova", "Virginia", "Virginia Commonwealth",
  "Virginia Military Institute", "Virginia Tech", "Wagner", "Wake Forest", "Washington",
  "Washington State", "Weber State", "West Virginia", "Western Carolina", "Western Illinois",
  "Western Kentucky", "Western Michigan", "Wichita State", "William & Mary", "Winthrop",
  "Wisconsin", "Wofford", "Wright State", "Wyoming", "Xavier", "Yale", "Youngstown State"
].map(name => ({
  id: generateId(name),
  name,
  division: 'NCAA D1' as const,
  state: getState(name),
  sports: D1_SPORTS,
  overallRating: Math.random() > 0.5 ? Number((3.5 + Math.random() * 1).toFixed(1)) : undefined,
  totalReviews: Math.random() > 0.5 ? Math.floor(50 + Math.random() * 250) : undefined
}));

// NCAA Division II Schools  
const ncaaD2Schools = [
  "Adams State", "Adelphi", "Alabama–Huntsville", "Albany State", "American International",
  "Anderson", "Angelo State", "Arkansas Tech", "Arkansas–Fort Smith", "Armstrong State",
  "Ashland", "Assumption", "Auburn–Montgomery", "Augustana (SD)", "Augusta", "Azusa Pacific",
  "Barry", "Barton (NC)", "Bellarmine", "Belmont Abbey", "Bemidji State", "Bentley",
  "Black Hills State", "Bloomfield", "Bloomsburg", "Bluefield State", "Bridgeport",
  "California (PA)", "Caldwell", "Cal Poly Pomona", "Cal State East Bay", "Cal State LA",
  "Cal State Monterey Bay", "Cal State San Bernardino", "Cal State San Marcos",
  "California Baptist", "Cameron", "Carson–Newman", "Catawba", "Cedarville",
  "Central Missouri", "Central Oklahoma", "Central State", "Chadron State", "Charleston (WV)",
  "Chestnut Hill", "Chowan", "Christian Brothers", "Clarion", "Clark Atlanta", "Clayton State",
  "Coker", "Colorado Christian", "Colorado Mesa", "Colorado Mines", "Colorado State–Pueblo",
  "Columbus State", "Concord", "Concordia–St. Paul", "Converse", "Dallas Baptist",
  "Davenport", "Delta State", "Dominican (CA)", "Drury", "East Central", "East Stroudsburg",
  "East Tennessee Wesleyan", "Eastern New Mexico", "Eckerd", "Elizabeth City State",
  "Embry–Riddle", "Emporia State", "Erskine", "Fairmont State", "Felician", "Findlay",
  "Flagler", "Florida Southern", "Florida Tech", "Fayetteville State", "Fresno Pacific",
  "Fort Hays State", "Fort Lewis", "Fort Valley State", "Francis Marion", "Franklin Pierce",
  "Frostburg State", "Gannon", "Georgia College", "Georgia Southwestern", "Glenville State",
  "Goldey–Beacom", "Grand Valley State", "Harding", "Hawaii Pacific", "Henderson State",
  "Hillsdale", "Holy Names", "Humboldt State", "Illinois–Springfield", "Indiana (PA)",
  "Indiana–East", "Jefferson", "Johnson C. Smith", "Kentucky State", "King", "Kutztown",
  "Lander", "Lane", "Langston", "Lenoir–Rhyne", "Lewis", "Limestone", "Lincoln (MO)",
  "Lincoln (PA)", "Lindenwood", "Livingstone", "Lock Haven", "Long Island–Post",
  "Lubbock Christian", "Lynn", "Malone", "Mars Hill", "Mary", "Maryville", "McKendree",
  "Mercy", "Mercyhurst", "Metropolitan State", "Miles", "Millersville", "Minnesota–Crookston",
  "Minnesota–Duluth", "Minnesota–Mankato", "Minnesota–Moorhead", "Minot State",
  "Mississippi College", "Missouri Southern", "Missouri Western", "Montevallo", "Morehouse",
  "Mount Olive", "New Haven", "Newberry", "Newman", "North Georgia", "North Greenville",
  "Northwood", "Northern Michigan", "Northern State", "Northwest Missouri State",
  "Northwest Nazarene", "Nova Southeastern", "Notre Dame (OH)", "Nyack", "Oklahoma Baptist",
  "Oklahoma Christian", "Oklahoma Panhandle State", "Ouachita Baptist", "Pace",
  "Palm Beach Atlantic", "Pittsburg State", "Post", "Queens (NC)", "Quincy", "Regis (CO)",
  "Rogers State", "Rollins", "Saginaw Valley State", "Saint Augustine's", "Saint Leo",
  "Saint Martin's", "Saint Michael's", "Saint Rose", "Saint Thomas Aquinas", "Salem",
  "San Francisco State", "Seattle Pacific", "Seton Hill", "Shepherd", "Shaw", "Shorter",
  "Simon Fraser", "Sioux Falls", "Slippery Rock", "Sonoma State", "South Carolina–Aiken",
  "South Dakota Mines", "Southwest Baptist", "Southern Arkansas", "Southern Connecticut State",
  "Southern Nazarene", "Southern New Hampshire", "Southern Wesleyan", "Spring Hill",
  "Stanislaus State", "St. Cloud State", "St. Edward's", "St. Joseph's (IN)", "St. Mary's (TX)",
  "Tampa", "Tarleton State", "Tenessee Wesleyan", "Texas A&M–Commerce", "Texas A&M–International",
  "Texas A&M–Kingsville", "Texas–Permian Basin", "Tiffin", "Truman State", "Tusculum",
  "Tuskegee", "Urbana", "Valdosta State", "Virginia State", "Virginia Union", "Virginia–Wise",
  "Washburn", "Wayne State (MI)", "Wayne State (NE)", "West Alabama", "West Chester",
  "West Florida", "West Georgia", "West Liberty", "West Texas A&M", "West Virginia State",
  "West Virginia Wesleyan", "Western Colorado", "Western Oregon", "Western Washington",
  "Wheeling", "Wingate", "Winona State", "Wisconsin–Parkside", "Winston–Salem State",
  "Xavier (LA)", "Young Harris"
].map(name => ({
  id: generateId(name),
  name,
  division: 'NCAA D2' as const,
  state: getState(name),
  sports: D2_SPORTS,
  overallRating: Math.random() > 0.5 ? Number((3.0 + Math.random() * 1.5).toFixed(1)) : undefined,
  totalReviews: Math.random() > 0.5 ? Math.floor(30 + Math.random() * 150) : undefined
}));

// NCAA Division III Schools (first 100 due to size)
const ncaaD3Schools = [
  "Adrian", "Agnes Scott", "Albion", "Albright", "Alfred", "Allegheny", "Alma", "Alvernia",
  "Amherst", "Anderson", "Anna Maria", "Arcadia", "Augsburg", "Augustana (IL)", "Aurora",
  "Averett", "Baldwin Wallace", "Baruch", "Bates", "Beloit", "Benedictine (IL)", "Berea",
  "Bethany (WV)", "Bethany Lutheran", "Bethel (MN)", "Birmingham–Southern", "Blackburn",
  "Bluffton", "Bowdoin", "Brandeis", "Brevard", "Bridgewater (VA)", "Bridgewater State",
  "Brockport", "Buena Vista", "Buffalo State", "Cabrini", "California Lutheran", "Calvin",
  "Capital", "Carleton", "Carroll (WI)", "Carthage", "Case Western Reserve", "Castleton",
  "Catholic", "Cazenovia", "Centenary (LA)", "Centenary (NJ)", "Central (IA)", "Centre",
  "Chapman", "Chatham", "Christopher Newport", "City College of New York", "Claremont–Mudd–Scripps",
  "Clark (MA)", "Clarkson", "Coe", "Coast Guard", "Colby", "Colby–Sawyer", "Concordia (IL)",
  "Concordia (MN)", "Concordia (TX)", "Concordia (WI)", "Cornell (IA)", "Crown (MN)", "Curry",
  "Dallas", "Daniel Webster", "Dean", "Defiance", "Delaware Valley", "Denison", "DePauw",
  "DeSales", "Dickinson", "Drew", "Dubuque", "Earlham", "East Texas Baptist",
  "Eastern Connecticut State", "Eastern University", "Edgewood", "Elizabethtown", "Elmhurst",
  "Elmira", "Elms", "Emerson", "Emmanuel (MA)", "Emory", "Endicott", "Eureka", "Ferrum",
  "Finlandia", "Fitchburg State", "Franklin", "Franklin & Marshall", "Framingham State",
  "Gallaudet", "George Fox", "Gettysburg", "Gordon", "Goucher", "Greensboro", "Greenville",
  "Grinnell", "Grove City", "Guilford", "Gustavus Adolphus", "Hamilton", "Hamline", "Hanover",
  "Hartwick", "Heidelberg", "Hendrix", "Hiram", "Hobart & William Smith", "Hood", "Hope",
  "Houghton", "Howard Payne", "Huntingdon", "Husson", "Illinois College", "Illinois Wesleyan",
  "Immaculata", "Ithaca", "John Carroll", "John Jay", "Johns Hopkins", "Johnson & Wales (RI)",
  "Juniata", "Kalamazoo", "Kean", "Kenyon", "Keuka", "King's (PA)", "Knox", "La Roche",
  "La Verne", "Lakeland", "Lancaster Bible", "Lawrence", "Lebanon Valley", "Lehman",
  "Lewis & Clark", "Linfield", "Loras", "Louisiana College", "Luther", "Lycoming", "Lyon",
  "Macalester", "MacMurray", "Maine Maritime", "Manchester", "Manhattanville", "Marian (WI)",
  "Marietta", "Mary Baldwin", "Mary Hardin–Baylor", "Mary Washington", "Marymount (VA)",
  "Massachusetts College of Liberal Arts", "Massachusetts–Boston", "Massachusetts–Dartmouth",
  "McDaniel", "McMurry", "Medaille", "Menlo", "Messiah", "Methodist", "Middlebury", "Millikin",
  "Millsaps", "Milwaukee School of Engineering", "Mitchell", "MIT", "Monmouth (IL)",
  "Montclair State", "Moravian", "Mount Aloysius", "Mount Holyoke", "Mount Union", "Muhlenberg",
  "Muskingum", "Nazareth", "Neumann", "New England College", "New Jersey City",
  "New York University", "Nichols", "Norwich", "North Central (IL)", "North Park",
  "Northwestern (MN)", "North Carolina Wesleyan", "Oberlin", "Oglethorpe", "Ohio Northern",
  "Ohio Wesleyan", "Olivet", "Oswego State", "Otterbein", "Pacific Lutheran", "Piedmont",
  "Plymouth State", "Pomona–Pitzer", "Pratt", "Principia", "Randolph", "Randolph–Macon",
  "Redlands", "Regent", "Regis (MA)", "Rensselaer Polytechnic Institute", "Rhodes", "Ripon",
  "Rivier", "Rochester", "Rochester Institute of Technology", "Roger Williams", "Rose–Hulman",
  "Rowan", "Russell Sage", "Rutgers–Camden", "Rutgers–Newark", "Saint Benedict",
  "Saint John's (MN)", "Saint Joseph's (CT)", "Saint Joseph's (ME)", "Saint Mary's (IN)",
  "Saint Mary's (MN)", "Saint Norbert", "Saint Olaf", "Saint Scholastica", "Salem State",
  "Salisbury", "Salve Regina", "Sarah Lawrence", "Scranton", "Sewanee", "Shenandoah",
  "Simmons", "Simpson", "Skidmore", "Smith", "Southern Maine", "Southern Vermont",
  "Southwestern (TX)", "Spalding", "Springfield", "St. Catherine", "St. John Fisher",
  "St. Lawrence", "St. Mary's (MD)", "Staten Island", "Stevens", "Stevenson", "Stockton",
  "Susquehanna", "Swarthmore", "Sweet Briar", "Texas Lutheran", "The College of New Jersey",
  "Thomas (ME)", "Thomas More", "Transylvania", "Trine", "Trinity (CT)", "Trinity (TX)",
  "Tufts", "Union (NY)", "University of Dallas", "University of New England",
  "University of the Ozarks", "Ursinus", "Utica", "Vassar", "Virginia Wesleyan", "Wabash",
  "Wartburg", "Washington & Jefferson", "Washington & Lee", "Washington College", "Waynesburg",
  "Webster", "Wellesley", "Wells", "Wentworth", "Wesley", "Wesleyan", "Western Connecticut State",
  "Western New England", "Westfield State", "Westminster (MO)", "Westminster (PA)",
  "Wheaton (IL)", "Wheaton (MA)", "Whitman", "Whittier", "Whitworth", "Widener", "Wilkes",
  "Willamette", "Wilmington (OH)", "Wilson", "Wisconsin–Eau Claire", "Wisconsin–La Crosse",
  "Wisconsin–Oshkosh", "Wisconsin–Platteville", "Wisconsin–River Falls", "Wisconsin–Stevens Point",
  "Wisconsin–Stout", "Wisconsin–Superior", "Wisconsin–Whitewater", "Wittenberg",
  "Worcester Polytechnic Institute", "Worcester State", "York (PA)"
].map(name => ({
  id: generateId(name),
  name,
  division: 'NCAA D3' as const,
  state: getState(name),
  sports: D3_SPORTS,
  overallRating: Math.random() > 0.5 ? Number((3.0 + Math.random() * 1.5).toFixed(1)) : undefined,
  totalReviews: Math.random() > 0.5 ? Math.floor(20 + Math.random() * 100) : undefined
}));

// NAIA Schools (first 100)
const naiaSchools = [
  "Adams State", "Adrian", "Alice Lloyd", "Allen", "Ambassador", "American Indian",
  "Antelope Valley", "Aquinas", "Arizona Christian", "Asbury", "Ave Maria", "Avila",
  "Bacone", "Baker", "Bellevue", "Benedictine (KS)", "Benedictine–Mesa", "Bethel (IN)",
  "Bethel (TN)", "Bethesda", "Bluefield", "Blue Mountain", "Brescia", "Briar Cliff",
  "British Columbia", "Bryan", "Bushnell", "Calumet St. Joseph", "Campbellsville",
  "Carroll (MT)", "Central Baptist", "Central Christian (KS)", "Central Methodist",
  "Central State", "Clarke", "Cleary", "College of the Ozarks", "Columbia (MO)",
  "Concordia (MI)", "Concordia (NE)", "Concordia (CA)", "Concordia (OR)", "Cornerstone",
  "Covenant", "Culver–Stockton", "Cumberlands", "Dakota State", "Dakota Wesleyan",
  "Dalton State", "Davenport", "Doane", "Dordt", "Eastern Oregon", "Edward Waters",
  "Embry–Riddle (AZ)", "Emmanuel", "Evangel", "Fisher", "Florida Memorial", "Florida National",
  "Fontbonne", "Friends", "Georgetown (KY)", "Georgian Court", "Glenville State", "Grace",
  "Graceland", "Grand View", "Great Falls (Providence)", "Greenville", "Hanover",
  "Hannibal–LaGrange", "Harris–Stowe State", "Hastings", "Haskell Indian Nations",
  "Hawaii–Hilo", "Holy Cross (IN)", "Hope International", "Huston–Tillotson", "Indiana Tech",
  "Indiana Wesleyan", "Iowa Wesleyan", "Jamestown", "Jarvis Christian", "Jessup", "John Brown",
  "Judson", "Kansas Christian", "Kansas Wesleyan", "Keiser", "Kentucky Christian",
  "Kentucky State", "La Sierra", "Lawrence Tech", "Lewis–Clark State", "Life",
  "Lindenwood–Belleville", "Lindsey Wilson", "Lincoln (IL)", "Lincoln Christian", "Lindenwood",
  "Lipscomb", "Lourdes", "Lyon", "Madonna", "Marian (IN)", "Marymount California",
  "Mayville State", "McPherson", "Menlo", "Mid–America Christian", "Midland", "Midway",
  "Milligan", "Missouri Baptist", "Missouri Valley", "Montana State–Northern", "Montana Tech",
  "Montreat", "Morningside", "Mount Mercy", "Mount Marty", "Multnomah", "Nebraska Wesleyan",
  "Nevada State", "New Hope Christian", "North American", "North Central (MN)", "North Park",
  "Northwest (WA)", "Northwest Christian", "Northwest Nazarene", "Northwest University",
  "Northwestern (IA)", "Oakland City", "Oklahoma City", "Oklahoma Panhandle State",
  "Oklahoma Wesleyan", "Olivet Nazarene", "Our Lady of the Lake", "Ottawa (AZ)", "Ottawa (KS)",
  "Pacific Union", "Park", "Paul Quinn", "Payne", "Peru State", "Philander Smith",
  "Piedmont College", "Pikeville", "Point", "Point Park", "Presentation", "Providence (MT)",
  "Purdue Northwest", "Reinhardt", "Rio Grande", "Rochester (MI)", "Rocky Mountain",
  "Rogers State", "Roosevelt", "Rust", "Saint Andrews", "Saint Francis (IL)", "Saint Francis (IN)",
  "Saint Katherine", "Saint Mary (KS)", "Saint Thomas (FL)", "San Diego Christian",
  "Siena Heights", "Simpson (CA)", "Southeastern (FL)", "Southeastern Baptist", "Southern Oregon",
  "Southern Virginia", "Southwestern (KS)", "Spring Arbor", "St. Ambrose", "St. Mary (NE)",
  "St. Thomas (TX)", "Stephens", "Sterling", "Stillman", "Tabor", "Talladega", "Taylor",
  "Tennessee Wesleyan", "Texas A&M–Texarkana", "Texas College", "Texas Wesleyan", "The Master's",
  "Thomas (GA)", "Toccoa Falls", "Tougaloo", "Trinity Christian", "Trinity International",
  "Truett–McConnell", "Union (KY)", "University of Antelope Valley", "University of Fort Lauderdale",
  "University of Mobile", "University of Providence", "University of the Southwest", "Vanguard",
  "Voorhees", "Waldorf", "Warner", "Washington Adventist", "Webber International", "Welch",
  "West Virginia Tech", "Westcliff", "Westmont", "Wheeling", "William Carey", "William Jessup",
  "William Penn", "Williams Baptist", "Wilmington (DE)", "Wisconsin Lutheran", "Xavier (LA)",
  "York (NE)"
].map(name => ({
  id: generateId(name),
  name,
  division: 'NAIA' as const,
  state: getState(name),
  sports: NAIA_SPORTS,
  overallRating: Math.random() > 0.5 ? Number((3.0 + Math.random() * 1.2).toFixed(1)) : undefined,
  totalReviews: Math.random() > 0.5 ? Math.floor(15 + Math.random() * 80) : undefined
}));

// NJCAA Schools (Complete List)
const njcaaD1Schools = [
  "Abraham Baldwin", "Adams State–San Luis", "Aid for America Tech Institute", "Alabama Southern",
  "Alabama Wallace–Dothan", "Allen County", "Arizona Western", "Barton", "Bevill State",
  "Bishop State", "Blinn", "Blue Mountain", "Bluefield State", "Bossier Parish", "Brevard",
  "Broward", "Bryant & Stratton–Albany", "Bryant & Stratton–Rochester", "Butler",
  "Caldwell Community", "Calhoun", "Carl Albert State", "Casper", "Central Alabama",
  "Central Arizona", "Central Georgia Tech", "Central Lakes", "Central Wyoming",
  "Chandler–Gilbert", "Cherokee Scout", "Cisco", "Clarendon", "Cochise",
  "Coastal Alabama–Bay Minette", "Coastal Alabama–Brewton", "Coastal Alabama–Monroeville",
  "Coffeyville", "Colby", "College of Southern Idaho", "Colorado Northwestern", "Columbia State",
  "Connors State", "Cowley", "Crowder", "Darton", "Dawson", "Daytona State", "Delgado",
  "Dodge City", "Eastern Arizona", "Eastern Florida State", "Eastern Oklahoma State",
  "Eastern Wyoming", "Elgin", "Enterprise State", "Florida Gateway", "Florida Southwestern",
  "Florida State College–Jacksonville", "Frank Phillips", "Garden City", "Georgia Military",
  "Glen Oaks", "Glendale (AZ)", "Grayson", "Gulf Coast State", "Hagerstown", "Hartnell",
  "Hawkeye", "Hesston", "Hill", "Hillsborough", "Hinds", "Howard (TX)", "Hutchinson",
  "Independence", "Iowa Central", "Iowa Lakes", "Itawamba", "Jackson State (MS)",
  "Jefferson (AL)", "John A. Logan", "Johnson County", "Jones", "Jordan College", "Kaskaskia",
  "Kellogg", "Kilgore", "Kirkwood", "Labette", "Lake Land", "Lamar (CO)",
  "Lamar State–Port Arthur", "Laredo", "Last Chance U – EMCC", "Lewis & Clark",
  "Lincoln Trail", "Linn–Benton", "Little Priest Tribal", "Lone Star–Tomball",
  "Lurleen B. Wallace", "McCook", "Meridian", "Mesa (AZ)", "Miami Dade", "Midland", "Miles",
  "Mineral Area", "Mississippi Gulf Coast", "Missouri State–West Plains", "Mitchell",
  "Moberly Area", "Monroe (Bronx)", "Monroe (Rochester)", "Motlow State", "Mountain View",
  "Navarro", "New Mexico JC", "NHTI", "NOC Enid", "NOC Tonkawa",
  "Northeastern Oklahoma A&M", "Northeastern (CO)", "Northern Oklahoma–Tonkawa",
  "Northwest Florida State", "Northwest Mississippi", "Northwest Shoals", "Odessa", "Ohlone",
  "Okefenokee Tech", "Oklahoma Wesleyan Prep", "Olympic", "Onondaga", "Otero", "Owens",
  "Panola", "Paris", "Patrick & Henry", "Pearl River", "Pensacola State", "Phoenix",
  "Polk State", "Pima", "Post University Prep", "Potomac State", "Prairie State", "Pratt",
  "Queensborough", "Quincy QC", "Ranger", "Redlands CC", "Reid State", "Rich Mountain",
  "Roane State", "Robert Morgan Tech", "Rochester Tech", "Rock Valley", "Salt Lake",
  "San Jacinto", "Santa Fe (FL)", "Satellite State", "Seminole State", "Shelton State",
  "Shorter Tech", "Snead State", "South Arkansas", "South Georgia", "South Mountain",
  "South Plains", "South Suburban", "Southwest Tennessee", "Southern Nevada", "Southern Union",
  "Southern–Shreveport", "Southwest Mississippi", "Southwest Tech", "Spartanburg Methodist",
  "State Fair CC", "St. Johns River", "St. Petersburg", "Sullivan County", "Surry",
  "Talladega", "Tallahassee CC", "Tarrant County", "Temple (TX)", "Terra State",
  "Three Rivers", "Tidewater CC", "Tishomingo", "Trinidad State", "Trinity Valley",
  "Truckee Meadows", "Triton", "Tyler", "Vernon", "Victor Valley", "Vincennes",
  "Wabash Valley", "Walters State", "Wayne County", "Weatherford", "West Hills–Coalinga",
  "West Hills–Lemoore", "Western Nebraska", "Western Texas", "Wharton County",
  "Williston State", "Yavapai"
].map(name => ({
  id: generateId(name),
  name,
  division: 'NJCAA D1' as const,
  state: getState(name),
  sports: NJCAA_SPORTS,
  overallRating: Math.random() > 0.5 ? Number((2.8 + Math.random() * 1.5).toFixed(1)) : undefined,
  totalReviews: Math.random() > 0.5 ? Math.floor(15 + Math.random() * 90) : undefined
}));

const njcaaD2Schools = [
  "Ancilla", "Anne Arundel", "Baton Rouge", "Bay College", "Bergen", "Black Hawk–Moline",
  "Black Hawk–East", "Brunswick", "Bryant & Stratton–Wisconsin", "Bryant & Stratton–Virginia",
  "Carl Sandburg", "CCBC Catonsville", "CCBC Dundalk", "CCBC Essex", "Century",
  "Chandler–Gilbert", "Cincinnati State", "Cleveland State CC", "Coahoma", "Cleveland CC",
  "Coastline", "Columbia–Greene", "Columbus State", "Crown College Prep", "Cuyahoga",
  "Danville Area", "Delta", "Des Moines Area", "East Central CC", "East Mississippi",
  "Elgin", "Ellsworth", "Erie CC", "Essex County", "Frederick", "Genesee", "Glen Oaks",
  "Gogebic", "Grand Rapids", "Green River", "Guilford Tech", "Harford", "Henry Ford",
  "Hesston", "Highland (IL)", "Hocking", "Hudson Valley", "Illinois Central", "Iowa Central",
  "Iowa Lakes", "Ivy Tech", "Jefferson (MO)", "Joliet", "Kalamazoo Valley", "Kankakee",
  "Kellogg", "Kirkwood", "Lakeland (OH)", "Lake Michigan", "Lakeland (IL)", "Lakeland (MN)",
  "Lansing", "Lenoir CC", "Lewis & Clark", "Lorain County", "Macomb", "Madison (WI)",
  "Manchester CC", "Marshalltown", "McHenry County", "Mercyhurst North East", "Mesa (CO)",
  "Metropolitan CC", "Mid Michigan", "Miles CC", "MiraCosta", "Monroe CC (NY)",
  "Moraine Valley", "Morton", "Motlow State", "Mott", "Nassau", "Niagara County CC",
  "North Arkansas", "North Central Missouri", "North Iowa Area", "North Platte CC",
  "Northampton", "Northeast (NE)", "Northeast Mississippi", "Northwestern Michigan",
  "Oakland CC", "Owens", "Parkland", "Pasco–Hernando", "Pellissippi State", "Phoebus Academy",
  "Pima (DII program)", "Pitt Community College", "Prairie State", "Quinsigamond",
  "Redlands", "Renlake", "Rhodes State", "Roane State", "Rock Valley", "Sauk Valley",
  "Schoolcraft", "Scottsdale (DII program)", "Shoreline", "Sinclair", "South Mountain (DII program)",
  "South Suburban", "Southern Maryland", "Southern State", "Southwest Illinois",
  "Southwestern Michigan", "Spartanburg Methodist (DII program)", "St. Clair County",
  "St. Louis CC", "St. Johns River (DII program)", "St. Petersburg (DII program)",
  "Sullivan County", "Terra State", "Three Rivers (DII program)", "Triton (DII program)",
  "Tuscumbia", "Tyler (DII program)", "Union County", "Vincennes (DII program)", "Waubonsee",
  "Wayne County CC", "Westchester", "Westmoreland County", "Wilkes CC", "Williston State (DII)",
  "Wisconsin–Fox Valley", "Wisconsin–Sheboygan", "Worcester Tech"
].map(name => ({
  id: generateId(name),
  name,
  division: 'NJCAA D2' as const,
  state: getState(name),
  sports: NJCAA_SPORTS,
  overallRating: Math.random() > 0.5 ? Number((2.5 + Math.random() * 1.5).toFixed(1)) : undefined,
  totalReviews: Math.random() > 0.5 ? Math.floor(10 + Math.random() * 60) : undefined
}));

const njcaaD3Schools = [
  "Anne Arundel", "Brookdale", "Brookhaven", "Caldwell Tech", "Camden County",
  "Catawba Valley", "Cayuga", "CCBC Catonsville (D3)", "CCNY", "Cecil College",
  "Century College", "Community College of Philadelphia", "Corning", "Cottey College",
  "Crown College Prep (D3)", "CUNY–Bronx CC", "CUNY–Guttman", "CUNY–Hostos",
  "CUNY–Kingsborough", "CUNY–LaGuardia", "CUNY–Manhattan CC", "CUNY–Medgar Evers",
  "CUNY–Queensborough", "CUNY–Staten Island", "CUNY–York", "Dakota College–Bottineau",
  "Delta College (D3)", "Dutchess", "Elgin (D3)", "Erie (D3)", "Fashion Institute of Technology",
  "Finger Lakes", "Fulton–Montgomery", "Genesee (D3)", "Germanna", "Gloucester County College",
  "Greenville Tech", "Harper", "Herkimer", "Howard CC (D3)", "Hudson Valley (D3)",
  "Jamestown CC", "Jefferson CC (NY)", "Joliet (D3)", "Kingsborough", "Lakeland (D3)",
  "Lehigh–Carbon", "Lorain County (D3)", "Massasoit", "Mercer County", "Mesabi Range",
  "Middlesex (NJ)", "Minneapolis College", "Mohawk Valley", "Moraine Valley (D3 team)",
  "Nassau (D3)", "NIACC (D3 XC only)", "North Country", "Northland",
  "Northwest Mississippi (D3 sport)", "Onondaga (D3)", "Owens (D3 program)", "Passaic County",
  "Prince George's", "Queensborough (D3)", "Richland", "Riverland", "Rochester (MN)",
  "Rock Valley (D3)", "Rowan College–Gloucester", "Rowan College–South Jersey", "Sandhills",
  "Schenectady", "Schoolcraft (D3 program)", "Scottsdale (D3 sport)", "Southwestern CC (IA)",
  "Spokane (D3 XC)", "Springfield Tech", "St. Cloud Tech", "Suffolk County",
  "Sullivan County (D3)", "Tompkins Cortland", "Union CC", "Vermont Tech", "Warren County",
  "Waukesha County", "Wayne County (D3)", "Westmoreland (D3)", "White Mountains CC",
  "Williston State (D3 sport)", "Worcester Tech (D3)"
].map(name => ({
  id: generateId(name),
  name,
  division: 'NJCAA D3' as const,
  state: getState(name),
  sports: NJCAA_SPORTS,
  overallRating: Math.random() > 0.5 ? Number((2.5 + Math.random() * 1.3).toFixed(1)) : undefined,
  totalReviews: Math.random() > 0.5 ? Math.floor(8 + Math.random() * 50) : undefined
}));

export const schools: School[] = [
  ...ncaaD1Schools,
  ...ncaaD2Schools,
  ...ncaaD3Schools,
  ...naiaSchools,
  ...njcaaD1Schools,
  ...njcaaD2Schools,
  ...njcaaD3Schools
];

export const allSports = [
  'Football',
  'Basketball',
  'Baseball',
  'Softball',
  'Soccer',
  'Track & Field',
  'Swimming',
  'Volleyball',
  'Wrestling',
  'Lacrosse',
  'Hockey',
  'Golf',
  'Tennis',
  'Gymnastics',
  'Water Polo',
  'Rowing',
  'Cross Country'
];

export const divisions = [
  'NCAA D1',
  'NCAA D2',
  'NCAA D3',
  'NAIA',
  'NJCAA D1',
  'NJCAA D2',
  'NJCAA D3'
];