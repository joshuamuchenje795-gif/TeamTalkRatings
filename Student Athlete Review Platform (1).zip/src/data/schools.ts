export interface School {
  id: string;
  name: string;
  division: 'NCAA D1' | 'NCAA D2' | 'NCAA D3' | 'NAIA' | 'NJCAA D1' | 'NJCAA D2' | 'NJCAA D3';
  state: string;
  sports: string[];
  overallRating?: number;
  totalReviews?: number;
}

export const schools: School[] = [
  // NCAA Division I Schools (Expanded)
  {
    id: 'usc',
    name: 'University of Southern California',
    division: 'NCAA D1',
    state: 'California',
    sports: ['Football', 'Basketball', 'Baseball', 'Soccer', 'Track & Field', 'Swimming', 'Volleyball', 'Water Polo'],
    overallRating: 4.5,
    totalReviews: 247
  },
  {
    id: 'duke',
    name: 'Duke University',
    division: 'NCAA D1',
    state: 'North Carolina',
    sports: ['Basketball', 'Football', 'Soccer', 'Lacrosse', 'Golf', 'Tennis', 'Track & Field'],
    overallRating: 4.5,
    totalReviews: 189
  },
  {
    id: 'stanford',
    name: 'Stanford University',
    division: 'NCAA D1',
    state: 'California',
    sports: ['Football', 'Basketball', 'Swimming', 'Track & Field', 'Soccer', 'Volleyball', 'Tennis', 'Golf'],
    overallRating: 4.5,
    totalReviews: 203
  },
  {
    id: 'texas',
    name: 'University of Texas',
    division: 'NCAA D1',
    state: 'Texas',
    sports: ['Football', 'Basketball', 'Baseball', 'Track & Field', 'Swimming', 'Volleyball', 'Golf', 'Tennis'],
    overallRating: 4.5,
    totalReviews: 312
  },
  {
    id: 'alabama',
    name: 'University of Alabama',
    division: 'NCAA D1',
    state: 'Alabama',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Gymnastics', 'Track & Field', 'Swimming'],
    overallRating: 4.3,
    totalReviews: 298
  },
  {
    id: 'michigan',
    name: 'University of Michigan',
    division: 'NCAA D1',
    state: 'Michigan',
    sports: ['Football', 'Basketball', 'Hockey', 'Baseball', 'Swimming', 'Track & Field', 'Wrestling', 'Gymnastics'],
    overallRating: 4.4,
    totalReviews: 276
  },
  {
    id: 'florida',
    name: 'University of Florida',
    division: 'NCAA D1',
    state: 'Florida',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Swimming', 'Track & Field', 'Volleyball', 'Golf'],
    overallRating: 4.2,
    totalReviews: 234
  },
  {
    id: 'ucla',
    name: 'University of California, Los Angeles',
    division: 'NCAA D1',
    state: 'California',
    sports: ['Football', 'Basketball', 'Soccer', 'Volleyball', 'Track & Field', 'Swimming', 'Gymnastics', 'Water Polo'],
    overallRating: 4.4,
    totalReviews: 265
  },
  {
    id: 'notre-dame',
    name: 'University of Notre Dame',
    division: 'NCAA D1',
    state: 'Indiana',
    sports: ['Football', 'Basketball', 'Lacrosse', 'Soccer', 'Hockey', 'Baseball', 'Track & Field'],
    overallRating: 4.3,
    totalReviews: 198
  },
  {
    id: 'ohio-state',
    name: 'Ohio State University',
    division: 'NCAA D1',
    state: 'Ohio',
    sports: ['Football', 'Basketball', 'Wrestling', 'Track & Field', 'Swimming', 'Hockey', 'Volleyball', 'Baseball'],
    overallRating: 4.4,
    totalReviews: 289
  },
  {
    id: 'georgia',
    name: 'University of Georgia',
    division: 'NCAA D1',
    state: 'Georgia',
    sports: ['Football', 'Basketball', 'Baseball', 'Gymnastics', 'Swimming', 'Track & Field', 'Softball', 'Volleyball'],
    overallRating: 4.3,
    totalReviews: 256
  },
  {
    id: 'clemson',
    name: 'Clemson University',
    division: 'NCAA D1',
    state: 'South Carolina',
    sports: ['Football', 'Basketball', 'Baseball', 'Soccer', 'Track & Field', 'Golf', 'Tennis'],
    overallRating: 4.2,
    totalReviews: 221
  },
  {
    id: 'oregon',
    name: 'University of Oregon',
    division: 'NCAA D1',
    state: 'Oregon',
    sports: ['Football', 'Basketball', 'Track & Field', 'Soccer', 'Softball', 'Volleyball', 'Golf'],
    overallRating: 4.1,
    totalReviews: 187
  },
  {
    id: 'penn-state',
    name: 'Pennsylvania State University',
    division: 'NCAA D1',
    state: 'Pennsylvania',
    sports: ['Football', 'Basketball', 'Wrestling', 'Volleyball', 'Hockey', 'Lacrosse', 'Track & Field'],
    overallRating: 4.3,
    totalReviews: 267
  },
  {
    id: 'uconn',
    name: 'University of Connecticut',
    division: 'NCAA D1',
    state: 'Connecticut',
    sports: ['Basketball', 'Football', 'Soccer', 'Hockey', 'Baseball', 'Softball', 'Track & Field'],
    overallRating: 4.2,
    totalReviews: 201
  },
  {
    id: 'lsu',
    name: 'Louisiana State University',
    division: 'NCAA D1',
    state: 'Louisiana',
    sports: ['Football', 'Basketball', 'Baseball', 'Track & Field', 'Gymnastics', 'Softball', 'Swimming'],
    overallRating: 4.2,
    totalReviews: 243
  },
  {
    id: 'auburn',
    name: 'Auburn University',
    division: 'NCAA D1',
    state: 'Alabama',
    sports: ['Football', 'Basketball', 'Baseball', 'Swimming', 'Track & Field', 'Gymnastics', 'Softball'],
    overallRating: 4.1,
    totalReviews: 212
  },
  {
    id: 'wisconsin',
    name: 'University of Wisconsin-Madison',
    division: 'NCAA D1',
    state: 'Wisconsin',
    sports: ['Football', 'Basketball', 'Hockey', 'Wrestling', 'Swimming', 'Track & Field', 'Rowing'],
    overallRating: 4.3,
    totalReviews: 234
  },
  {
    id: 'tennessee',
    name: 'University of Tennessee',
    division: 'NCAA D1',
    state: 'Tennessee',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Track & Field', 'Swimming', 'Volleyball'],
    overallRating: 4.2,
    totalReviews: 198
  },
  {
    id: 'texas-am',
    name: 'Texas A&M University',
    division: 'NCAA D1',
    state: 'Texas',
    sports: ['Football', 'Basketball', 'Baseball', 'Soccer', 'Swimming', 'Track & Field', 'Golf'],
    overallRating: 4.1,
    totalReviews: 187
  },
  {
    id: 'oklahoma',
    name: 'University of Oklahoma',
    division: 'NCAA D1',
    state: 'Oklahoma',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Gymnastics', 'Wrestling', 'Track & Field'],
    overallRating: 4.2,
    totalReviews: 203
  },
  {
    id: 'kentucky',
    name: 'University of Kentucky',
    division: 'NCAA D1',
    state: 'Kentucky',
    sports: ['Basketball', 'Football', 'Baseball', 'Softball', 'Track & Field', 'Swimming', 'Volleyball'],
    overallRating: 4.1,
    totalReviews: 176
  },
  {
    id: 'north-carolina',
    name: 'University of North Carolina',
    division: 'NCAA D1',
    state: 'North Carolina',
    sports: ['Basketball', 'Football', 'Soccer', 'Lacrosse', 'Baseball', 'Track & Field', 'Swimming'],
    overallRating: 4.3,
    totalReviews: 221
  },
  {
    id: 'kansas',
    name: 'University of Kansas',
    division: 'NCAA D1',
    state: 'Kansas',
    sports: ['Basketball', 'Football', 'Track & Field', 'Volleyball', 'Baseball', 'Softball', 'Swimming'],
    overallRating: 4.0,
    totalReviews: 154
  },
  {
    id: 'florida-state',
    name: 'Florida State University',
    division: 'NCAA D1',
    state: 'Florida',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Track & Field', 'Swimming', 'Soccer'],
    overallRating: 4.1,
    totalReviews: 189
  },
  {
    id: 'miami',
    name: 'University of Miami',
    division: 'NCAA D1',
    state: 'Florida',
    sports: ['Football', 'Basketball', 'Baseball', 'Track & Field', 'Swimming', 'Tennis', 'Rowing'],
    overallRating: 4.0,
    totalReviews: 167
  },
  {
    id: 'virginia',
    name: 'University of Virginia',
    division: 'NCAA D1',
    state: 'Virginia',
    sports: ['Football', 'Basketball', 'Lacrosse', 'Soccer', 'Baseball', 'Track & Field', 'Swimming'],
    overallRating: 4.2,
    totalReviews: 178
  },
  {
    id: 'washington',
    name: 'University of Washington',
    division: 'NCAA D1',
    state: 'Washington',
    sports: ['Football', 'Basketball', 'Rowing', 'Soccer', 'Volleyball', 'Track & Field', 'Swimming'],
    overallRating: 4.1,
    totalReviews: 193
  },
  {
    id: 'arizona',
    name: 'University of Arizona',
    division: 'NCAA D1',
    state: 'Arizona',
    sports: ['Basketball', 'Football', 'Baseball', 'Softball', 'Swimming', 'Track & Field', 'Golf'],
    overallRating: 4.0,
    totalReviews: 171
  },
  {
    id: 'nebraska',
    name: 'University of Nebraska',
    division: 'NCAA D1',
    state: 'Nebraska',
    sports: ['Football', 'Basketball', 'Volleyball', 'Wrestling', 'Baseball', 'Track & Field', 'Gymnastics'],
    overallRating: 4.1,
    totalReviews: 182
  },
  {
    id: 'iowa',
    name: 'University of Iowa',
    division: 'NCAA D1',
    state: 'Iowa',
    sports: ['Football', 'Basketball', 'Wrestling', 'Baseball', 'Track & Field', 'Swimming', 'Volleyball'],
    overallRating: 4.0,
    totalReviews: 165
  },
  {
    id: 'michigan-state',
    name: 'Michigan State University',
    division: 'NCAA D1',
    state: 'Michigan',
    sports: ['Football', 'Basketball', 'Hockey', 'Wrestling', 'Soccer', 'Track & Field', 'Baseball'],
    overallRating: 4.0,
    totalReviews: 173
  },
  {
    id: 'arkansas',
    name: 'University of Arkansas',
    division: 'NCAA D1',
    state: 'Arkansas',
    sports: ['Football', 'Basketball', 'Baseball', 'Track & Field', 'Softball', 'Gymnastics', 'Swimming'],
    overallRating: 3.9,
    totalReviews: 158
  },
  {
    id: 'south-carolina',
    name: 'University of South Carolina',
    division: 'NCAA D1',
    state: 'South Carolina',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Soccer', 'Track & Field', 'Swimming'],
    overallRating: 3.9,
    totalReviews: 149
  },
  {
    id: 'missouri',
    name: 'University of Missouri',
    division: 'NCAA D1',
    state: 'Missouri',
    sports: ['Football', 'Basketball', 'Baseball', 'Wrestling', 'Track & Field', 'Swimming', 'Softball'],
    overallRating: 3.8,
    totalReviews: 142
  },
  {
    id: 'mississippi',
    name: 'University of Mississippi',
    division: 'NCAA D1',
    state: 'Mississippi',
    sports: ['Football', 'Basketball', 'Baseball', 'Golf', 'Tennis', 'Track & Field', 'Soccer'],
    overallRating: 3.9,
    totalReviews: 136
  },
  {
    id: 'baylor',
    name: 'Baylor University',
    division: 'NCAA D1',
    state: 'Texas',
    sports: ['Football', 'Basketball', 'Baseball', 'Tennis', 'Track & Field', 'Soccer', 'Softball'],
    overallRating: 4.0,
    totalReviews: 148
  },
  {
    id: 'tcu',
    name: 'Texas Christian University',
    division: 'NCAA D1',
    state: 'Texas',
    sports: ['Football', 'Basketball', 'Baseball', 'Golf', 'Track & Field', 'Swimming', 'Tennis'],
    overallRating: 3.9,
    totalReviews: 127
  },
  {
    id: 'colorado',
    name: 'University of Colorado',
    division: 'NCAA D1',
    state: 'Colorado',
    sports: ['Football', 'Basketball', 'Track & Field', 'Cross Country', 'Skiing', 'Soccer', 'Lacrosse'],
    overallRating: 3.9,
    totalReviews: 139
  },
  {
    id: 'utah',
    name: 'University of Utah',
    division: 'NCAA D1',
    state: 'Utah',
    sports: ['Football', 'Basketball', 'Gymnastics', 'Skiing', 'Swimming', 'Track & Field', 'Soccer'],
    overallRating: 3.9,
    totalReviews: 145
  },
  {
    id: 'arizona-state',
    name: 'Arizona State University',
    division: 'NCAA D1',
    state: 'Arizona',
    sports: ['Football', 'Basketball', 'Baseball', 'Wrestling', 'Swimming', 'Track & Field', 'Golf'],
    overallRating: 3.8,
    totalReviews: 156
  },

  // NCAA Division II Schools (Expanded)
  {
    id: 'grand-valley',
    name: 'Grand Valley State University',
    division: 'NCAA D2',
    state: 'Michigan',
    sports: ['Football', 'Basketball', 'Track & Field', 'Soccer', 'Volleyball', 'Baseball', 'Softball'],
    overallRating: 4.1,
    totalReviews: 156
  },
  {
    id: 'minn-duluth',
    name: 'University of Minnesota Duluth',
    division: 'NCAA D2',
    state: 'Minnesota',
    sports: ['Hockey', 'Football', 'Basketball', 'Track & Field', 'Soccer', 'Volleyball'],
    overallRating: 4.0,
    totalReviews: 134
  },
  {
    id: 'west-florida',
    name: 'University of West Florida',
    division: 'NCAA D2',
    state: 'Florida',
    sports: ['Football', 'Basketball', 'Soccer', 'Softball', 'Volleyball', 'Baseball', 'Cross Country'],
    overallRating: 3.9,
    totalReviews: 112
  },
  {
    id: 'ashland',
    name: 'Ashland University',
    division: 'NCAA D2',
    state: 'Ohio',
    sports: ['Football', 'Basketball', 'Track & Field', 'Swimming', 'Wrestling', 'Soccer', 'Baseball'],
    overallRating: 4.0,
    totalReviews: 98
  },
  {
    id: 'csu-chico',
    name: 'California State University, Chico',
    division: 'NCAA D2',
    state: 'California',
    sports: ['Basketball', 'Soccer', 'Volleyball', 'Track & Field', 'Golf', 'Softball', 'Baseball'],
    overallRating: 3.8,
    totalReviews: 87
  },
  {
    id: 'ferris-state',
    name: 'Ferris State University',
    division: 'NCAA D2',
    state: 'Michigan',
    sports: ['Football', 'Hockey', 'Basketball', 'Track & Field', 'Cross Country', 'Golf', 'Tennis'],
    overallRating: 3.9,
    totalReviews: 93
  },
  {
    id: 'central-missouri',
    name: 'University of Central Missouri',
    division: 'NCAA D2',
    state: 'Missouri',
    sports: ['Football', 'Basketball', 'Track & Field', 'Wrestling', 'Baseball', 'Softball', 'Volleyball'],
    overallRating: 3.8,
    totalReviews: 86
  },
  {
    id: 'valdosta-state',
    name: 'Valdosta State University',
    division: 'NCAA D2',
    state: 'Georgia',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Tennis', 'Volleyball', 'Soccer'],
    overallRating: 3.9,
    totalReviews: 91
  },
  {
    id: 'wingate',
    name: 'Wingate University',
    division: 'NCAA D2',
    state: 'North Carolina',
    sports: ['Football', 'Basketball', 'Baseball', 'Soccer', 'Swimming', 'Track & Field', 'Lacrosse'],
    overallRating: 3.7,
    totalReviews: 78
  },
  {
    id: 'pittsburg-state',
    name: 'Pittsburg State University',
    division: 'NCAA D2',
    state: 'Kansas',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Track & Field', 'Cross Country'],
    overallRating: 3.8,
    totalReviews: 82
  },
  {
    id: 'northwest-missouri',
    name: 'Northwest Missouri State University',
    division: 'NCAA D2',
    state: 'Missouri',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Track & Field', 'Tennis', 'Golf'],
    overallRating: 3.9,
    totalReviews: 89
  },
  {
    id: 'angelo-state',
    name: 'Angelo State University',
    division: 'NCAA D2',
    state: 'Texas',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Track & Field', 'Cross Country'],
    overallRating: 3.7,
    totalReviews: 74
  },
  {
    id: 'tarleton-state',
    name: 'Tarleton State University',
    division: 'NCAA D2',
    state: 'Texas',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Track & Field', 'Cross Country'],
    overallRating: 3.7,
    totalReviews: 71
  },
  {
    id: 'colorado-mines',
    name: 'Colorado School of Mines',
    division: 'NCAA D2',
    state: 'Colorado',
    sports: ['Football', 'Basketball', 'Track & Field', 'Swimming', 'Wrestling', 'Soccer', 'Baseball'],
    overallRating: 3.9,
    totalReviews: 84
  },
  {
    id: 'bentley',
    name: 'Bentley University',
    division: 'NCAA D2',
    state: 'Massachusetts',
    sports: ['Basketball', 'Hockey', 'Soccer', 'Lacrosse', 'Track & Field', 'Baseball', 'Softball'],
    overallRating: 3.8,
    totalReviews: 79
  },

  // NCAA Division III Schools (Expanded)
  {
    id: 'williams',
    name: 'Williams College',
    division: 'NCAA D3',
    state: 'Massachusetts',
    sports: ['Football', 'Basketball', 'Soccer', 'Swimming', 'Track & Field', 'Lacrosse', 'Tennis', 'Golf'],
    overallRating: 4.2,
    totalReviews: 76
  },
  {
    id: 'amherst',
    name: 'Amherst College',
    division: 'NCAA D3',
    state: 'Massachusetts',
    sports: ['Football', 'Basketball', 'Soccer', 'Lacrosse', 'Swimming', 'Track & Field', 'Tennis'],
    overallRating: 4.1,
    totalReviews: 68
  },
  {
    id: 'mit',
    name: 'Massachusetts Institute of Technology',
    division: 'NCAA D3',
    state: 'Massachusetts',
    sports: ['Football', 'Basketball', 'Swimming', 'Track & Field', 'Soccer', 'Rowing', 'Wrestling'],
    overallRating: 3.9,
    totalReviews: 92
  },
  {
    id: 'uww',
    name: 'University of Wisconsin-Whitewater',
    division: 'NCAA D3',
    state: 'Wisconsin',
    sports: ['Football', 'Basketball', 'Track & Field', 'Wrestling', 'Soccer', 'Volleyball', 'Baseball'],
    overallRating: 4.0,
    totalReviews: 103
  },
  {
    id: 'johns-hopkins',
    name: 'Johns Hopkins University',
    division: 'NCAA D3',
    state: 'Maryland',
    sports: ['Lacrosse', 'Soccer', 'Basketball', 'Swimming', 'Track & Field', 'Baseball', 'Wrestling'],
    overallRating: 4.1,
    totalReviews: 85
  },
  {
    id: 'emory',
    name: 'Emory University',
    division: 'NCAA D3',
    state: 'Georgia',
    sports: ['Basketball', 'Soccer', 'Swimming', 'Track & Field', 'Tennis', 'Volleyball', 'Baseball'],
    overallRating: 3.9,
    totalReviews: 71
  },
  {
    id: 'middlebury',
    name: 'Middlebury College',
    division: 'NCAA D3',
    state: 'Vermont',
    sports: ['Football', 'Basketball', 'Soccer', 'Lacrosse', 'Skiing', 'Swimming', 'Track & Field'],
    overallRating: 4.0,
    totalReviews: 64
  },
  {
    id: 'bowdoin',
    name: 'Bowdoin College',
    division: 'NCAA D3',
    state: 'Maine',
    sports: ['Football', 'Basketball', 'Soccer', 'Lacrosse', 'Swimming', 'Track & Field', 'Rowing'],
    overallRating: 4.0,
    totalReviews: 59
  },
  {
    id: 'tufts',
    name: 'Tufts University',
    division: 'NCAA D3',
    state: 'Massachusetts',
    sports: ['Football', 'Basketball', 'Soccer', 'Lacrosse', 'Swimming', 'Track & Field', 'Sailing'],
    overallRating: 3.9,
    totalReviews: 67
  },
  {
    id: 'washington-stl',
    name: 'Washington University in St. Louis',
    division: 'NCAA D3',
    state: 'Missouri',
    sports: ['Basketball', 'Soccer', 'Swimming', 'Track & Field', 'Tennis', 'Volleyball', 'Baseball'],
    overallRating: 4.0,
    totalReviews: 73
  },
  {
    id: 'carnegie-mellon',
    name: 'Carnegie Mellon University',
    division: 'NCAA D3',
    state: 'Pennsylvania',
    sports: ['Football', 'Basketball', 'Soccer', 'Swimming', 'Track & Field', 'Tennis', 'Golf'],
    overallRating: 3.8,
    totalReviews: 61
  },
  {
    id: 'rochester',
    name: 'University of Rochester',
    division: 'NCAA D3',
    state: 'New York',
    sports: ['Basketball', 'Soccer', 'Swimming', 'Track & Field', 'Squash', 'Baseball', 'Volleyball'],
    overallRating: 3.8,
    totalReviews: 58
  },
  {
    id: 'case-western',
    name: 'Case Western Reserve University',
    division: 'NCAA D3',
    state: 'Ohio',
    sports: ['Football', 'Basketball', 'Soccer', 'Swimming', 'Track & Field', 'Wrestling', 'Baseball'],
    overallRating: 3.7,
    totalReviews: 54
  },
  {
    id: 'chicago',
    name: 'University of Chicago',
    division: 'NCAA D3',
    state: 'Illinois',
    sports: ['Basketball', 'Soccer', 'Swimming', 'Track & Field', 'Tennis', 'Volleyball', 'Baseball'],
    overallRating: 3.9,
    totalReviews: 69
  },
  {
    id: 'ithaca',
    name: 'Ithaca College',
    division: 'NCAA D3',
    state: 'New York',
    sports: ['Football', 'Basketball', 'Soccer', 'Lacrosse', 'Swimming', 'Track & Field', 'Wrestling'],
    overallRating: 3.8,
    totalReviews: 77
  },

  // NAIA Schools (Expanded)
  {
    id: 'naia-baker',
    name: 'Baker University',
    division: 'NAIA',
    state: 'Kansas',
    sports: ['Football', 'Basketball', 'Track & Field', 'Soccer', 'Volleyball', 'Baseball', 'Softball'],
    overallRating: 3.8,
    totalReviews: 64
  },
  {
    id: 'naia-biola',
    name: 'Biola University',
    division: 'NAIA',
    state: 'California',
    sports: ['Basketball', 'Soccer', 'Swimming', 'Track & Field', 'Volleyball', 'Baseball', 'Softball'],
    overallRating: 4.0,
    totalReviews: 71
  },
  {
    id: 'naia-snu',
    name: 'Southern Nazarene University',
    division: 'NAIA',
    state: 'Oklahoma',
    sports: ['Basketball', 'Football', 'Baseball', 'Soccer', 'Track & Field', 'Volleyball'],
    overallRating: 3.7,
    totalReviews: 58
  },
  {
    id: 'naia-lindsey',
    name: 'Lindsey Wilson College',
    division: 'NAIA',
    state: 'Kentucky',
    sports: ['Football', 'Basketball', 'Soccer', 'Wrestling', 'Track & Field', 'Volleyball', 'Golf'],
    overallRating: 3.9,
    totalReviews: 62
  },
  {
    id: 'naia-cumberland',
    name: 'Cumberland University',
    division: 'NAIA',
    state: 'Tennessee',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Soccer', 'Track & Field', 'Wrestling'],
    overallRating: 3.8,
    totalReviews: 69
  },
  {
    id: 'naia-morningside',
    name: 'Morningside University',
    division: 'NAIA',
    state: 'Iowa',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Soccer', 'Track & Field', 'Wrestling'],
    overallRating: 3.7,
    totalReviews: 55
  },
  {
    id: 'naia-doane',
    name: 'Doane University',
    division: 'NAIA',
    state: 'Nebraska',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Soccer', 'Track & Field', 'Wrestling'],
    overallRating: 3.6,
    totalReviews: 52
  },
  {
    id: 'naia-northwestern',
    name: 'Northwestern College',
    division: 'NAIA',
    state: 'Iowa',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Soccer', 'Track & Field', 'Wrestling'],
    overallRating: 3.8,
    totalReviews: 61
  },
  {
    id: 'naia-concordia',
    name: 'Concordia University',
    division: 'NAIA',
    state: 'Nebraska',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Soccer', 'Track & Field', 'Volleyball'],
    overallRating: 3.7,
    totalReviews: 57
  },
  {
    id: 'naia-gcu',
    name: 'Grand Canyon University',
    division: 'NAIA',
    state: 'Arizona',
    sports: ['Basketball', 'Baseball', 'Softball', 'Soccer', 'Swimming', 'Track & Field', 'Volleyball'],
    overallRating: 3.9,
    totalReviews: 78
  },
  {
    id: 'naia-westmont',
    name: 'Westmont College',
    division: 'NAIA',
    state: 'California',
    sports: ['Basketball', 'Soccer', 'Track & Field', 'Cross Country', 'Volleyball', 'Baseball'],
    overallRating: 3.7,
    totalReviews: 48
  },
  {
    id: 'naia-azusa',
    name: 'Azusa Pacific University',
    division: 'NAIA',
    state: 'California',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Soccer', 'Track & Field', 'Volleyball'],
    overallRating: 3.8,
    totalReviews: 65
  },
  {
    id: 'naia-point-loma',
    name: 'Point Loma Nazarene University',
    division: 'NAIA',
    state: 'California',
    sports: ['Basketball', 'Soccer', 'Tennis', 'Volleyball', 'Track & Field', 'Cross Country'],
    overallRating: 3.7,
    totalReviews: 51
  },
  {
    id: 'naia-embry-riddle',
    name: 'Embry-Riddle Aeronautical University',
    division: 'NAIA',
    state: 'Florida',
    sports: ['Basketball', 'Soccer', 'Baseball', 'Softball', 'Volleyball', 'Track & Field'],
    overallRating: 3.6,
    totalReviews: 44
  },
  {
    id: 'naia-siena-heights',
    name: 'Siena Heights University',
    division: 'NAIA',
    state: 'Michigan',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Soccer', 'Track & Field', 'Volleyball'],
    overallRating: 3.5,
    totalReviews: 41
  },

  // NJCAA Division I Schools (Expanded)
  {
    id: 'njcaa-iowa-central',
    name: 'Iowa Central Community College',
    division: 'NJCAA D1',
    state: 'Iowa',
    sports: ['Football', 'Basketball', 'Baseball', 'Wrestling', 'Track & Field', 'Volleyball', 'Softball'],
    overallRating: 3.9,
    totalReviews: 94
  },
  {
    id: 'njcaa-trinity',
    name: 'Trinity Valley Community College',
    division: 'NJCAA D1',
    state: 'Texas',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Track & Field', 'Volleyball'],
    overallRating: 3.7,
    totalReviews: 81
  },
  {
    id: 'njcaa-butler',
    name: 'Butler Community College',
    division: 'NJCAA D1',
    state: 'Kansas',
    sports: ['Basketball', 'Baseball', 'Softball', 'Volleyball', 'Soccer', 'Track & Field'],
    overallRating: 3.8,
    totalReviews: 76
  },
  {
    id: 'njcaa-azwestern',
    name: 'Arizona Western College',
    division: 'NJCAA D1',
    state: 'Arizona',
    sports: ['Football', 'Baseball', 'Softball', 'Basketball', 'Soccer', 'Track & Field'],
    overallRating: 3.6,
    totalReviews: 72
  },
  {
    id: 'njcaa-independence',
    name: 'Independence Community College',
    division: 'NJCAA D1',
    state: 'Kansas',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Track & Field', 'Volleyball'],
    overallRating: 3.7,
    totalReviews: 68
  },
  {
    id: 'njcaa-coahoma',
    name: 'Coahoma Community College',
    division: 'NJCAA D1',
    state: 'Mississippi',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Track & Field'],
    overallRating: 3.5,
    totalReviews: 59
  },
  {
    id: 'njcaa-copiah',
    name: 'Copiah-Lincoln Community College',
    division: 'NJCAA D1',
    state: 'Mississippi',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Soccer', 'Track & Field'],
    overallRating: 3.6,
    totalReviews: 64
  },
  {
    id: 'njcaa-navarro',
    name: 'Navarro College',
    division: 'NJCAA D1',
    state: 'Texas',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Volleyball'],
    overallRating: 3.6,
    totalReviews: 71
  },
  {
    id: 'njcaa-northeast-ms',
    name: 'Northeast Mississippi Community College',
    division: 'NJCAA D1',
    state: 'Mississippi',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Soccer'],
    overallRating: 3.5,
    totalReviews: 56
  },
  {
    id: 'njcaa-iowa-western',
    name: 'Iowa Western Community College',
    division: 'NJCAA D1',
    state: 'Iowa',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Wrestling', 'Track & Field', 'Volleyball'],
    overallRating: 3.8,
    totalReviews: 85
  },
  {
    id: 'njcaa-gvsu',
    name: 'Garden City Community College',
    division: 'NJCAA D1',
    state: 'Kansas',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Track & Field', 'Volleyball'],
    overallRating: 3.6,
    totalReviews: 63
  },
  {
    id: 'njcaa-blinn',
    name: 'Blinn College',
    division: 'NJCAA D1',
    state: 'Texas',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Volleyball'],
    overallRating: 3.7,
    totalReviews: 77
  },
  {
    id: 'njcaa-hinds',
    name: 'Hinds Community College',
    division: 'NJCAA D1',
    state: 'Mississippi',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Soccer', 'Track & Field'],
    overallRating: 3.6,
    totalReviews: 69
  },
  {
    id: 'njcaa-kilgore',
    name: 'Kilgore College',
    division: 'NJCAA D1',
    state: 'Texas',
    sports: ['Football', 'Basketball', 'Baseball', 'Softball', 'Track & Field'],
    overallRating: 3.5,
    totalReviews: 61
  },
  {
    id: 'njcaa-ellsworth',
    name: 'Ellsworth Community College',
    division: 'NJCAA D1',
    state: 'Iowa',
    sports: ['Football', 'Basketball', 'Baseball', 'Wrestling', 'Track & Field', 'Volleyball'],
    overallRating: 3.6,
    totalReviews: 58
  },

  // NJCAA Division II Schools (Expanded)
  {
    id: 'njcaa-essex',
    name: 'Essex Community College',
    division: 'NJCAA D2',
    state: 'Maryland',
    sports: ['Basketball', 'Soccer', 'Baseball', 'Softball', 'Lacrosse'],
    overallRating: 3.5,
    totalReviews: 48
  },
  {
    id: 'njcaa-collin',
    name: 'Collin College',
    division: 'NJCAA D2',
    state: 'Texas',
    sports: ['Basketball', 'Baseball', 'Softball', 'Tennis', 'Volleyball'],
    overallRating: 3.6,
    totalReviews: 52
  },
  {
    id: 'njcaa-pima',
    name: 'Pima Community College',
    division: 'NJCAA D2',
    state: 'Arizona',
    sports: ['Basketball', 'Baseball', 'Soccer', 'Cross Country', 'Track & Field'],
    overallRating: 3.4,
    totalReviews: 46
  },
  {
    id: 'njcaa-north-iowa',
    name: 'North Iowa Area Community College',
    division: 'NJCAA D2',
    state: 'Iowa',
    sports: ['Basketball', 'Baseball', 'Softball', 'Wrestling', 'Volleyball'],
    overallRating: 3.5,
    totalReviews: 49
  },
  {
    id: 'njcaa-kirkwood',
    name: 'Kirkwood Community College',
    division: 'NJCAA D2',
    state: 'Iowa',
    sports: ['Basketball', 'Baseball', 'Softball', 'Volleyball', 'Golf'],
    overallRating: 3.5,
    totalReviews: 51
  },
  {
    id: 'njcaa-meridian',
    name: 'Meridian Community College',
    division: 'NJCAA D2',
    state: 'Mississippi',
    sports: ['Basketball', 'Baseball', 'Softball', 'Soccer'],
    overallRating: 3.3,
    totalReviews: 42
  },
  {
    id: 'njcaa-delaware',
    name: 'Delaware Technical Community College',
    division: 'NJCAA D2',
    state: 'Delaware',
    sports: ['Basketball', 'Baseball', 'Softball', 'Lacrosse', 'Soccer'],
    overallRating: 3.4,
    totalReviews: 44
  },
  {
    id: 'njcaa-scott',
    name: 'Scott Community College',
    division: 'NJCAA D2',
    state: 'Iowa',
    sports: ['Basketball', 'Baseball', 'Softball', 'Volleyball'],
    overallRating: 3.3,
    totalReviews: 39
  },
  {
    id: 'njcaa-mott',
    name: 'Mott Community College',
    division: 'NJCAA D2',
    state: 'Michigan',
    sports: ['Basketball', 'Baseball', 'Cross Country', 'Volleyball'],
    overallRating: 3.4,
    totalReviews: 43
  },
  {
    id: 'njcaa-central-alabama',
    name: 'Central Alabama Community College',
    division: 'NJCAA D2',
    state: 'Alabama',
    sports: ['Basketball', 'Baseball', 'Softball'],
    overallRating: 3.3,
    totalReviews: 37
  },

  // NJCAA Division III Schools (Expanded)
  {
    id: 'njcaa-hcc',
    name: 'Herkimer County Community College',
    division: 'NJCAA D3',
    state: 'New York',
    sports: ['Basketball', 'Soccer', 'Baseball', 'Softball', 'Swimming', 'Track & Field'],
    overallRating: 3.4,
    totalReviews: 41
  },
  {
    id: 'njcaa-nassau',
    name: 'Nassau Community College',
    division: 'NJCAA D3',
    state: 'New York',
    sports: ['Basketball', 'Soccer', 'Baseball', 'Lacrosse', 'Track & Field'],
    overallRating: 3.5,
    totalReviews: 45
  },
  {
    id: 'njcaa-suffolk',
    name: 'Suffolk County Community College',
    division: 'NJCAA D3',
    state: 'New York',
    sports: ['Basketball', 'Soccer', 'Baseball', 'Lacrosse', 'Cross Country'],
    overallRating: 3.4,
    totalReviews: 43
  },
  {
    id: 'njcaa-onondaga',
    name: 'Onondaga Community College',
    division: 'NJCAA D3',
    state: 'New York',
    sports: ['Basketball', 'Soccer', 'Baseball', 'Lacrosse', 'Track & Field'],
    overallRating: 3.5,
    totalReviews: 47
  },
  {
    id: 'njcaa-monroe',
    name: 'Monroe Community College',
    division: 'NJCAA D3',
    state: 'New York',
    sports: ['Basketball', 'Soccer', 'Baseball', 'Swimming', 'Volleyball'],
    overallRating: 3.3,
    totalReviews: 38
  },
  {
    id: 'njcaa-rockland',
    name: 'Rockland Community College',
    division: 'NJCAA D3',
    state: 'New York',
    sports: ['Basketball', 'Soccer', 'Baseball', 'Softball'],
    overallRating: 3.2,
    totalReviews: 34
  },
  {
    id: 'njcaa-westchester',
    name: 'Westchester Community College',
    division: 'NJCAA D3',
    state: 'New York',
    sports: ['Basketball', 'Soccer', 'Baseball', 'Volleyball', 'Bowling'],
    overallRating: 3.3,
    totalReviews: 36
  },
  {
    id: 'njcaa-ccri',
    name: 'Community College of Rhode Island',
    division: 'NJCAA D3',
    state: 'Rhode Island',
    sports: ['Basketball', 'Soccer', 'Baseball', 'Softball', 'Golf'],
    overallRating: 3.2,
    totalReviews: 33
  },
  {
    id: 'njcaa-broward',
    name: 'Broward College',
    division: 'NJCAA D3',
    state: 'Florida',
    sports: ['Basketball', 'Baseball', 'Softball', 'Volleyball'],
    overallRating: 3.4,
    totalReviews: 40
  },
  {
    id: 'njcaa-bergen',
    name: 'Bergen Community College',
    division: 'NJCAA D3',
    state: 'New Jersey',
    sports: ['Basketball', 'Soccer', 'Baseball', 'Softball', 'Track & Field'],
    overallRating: 3.3,
    totalReviews: 38
  },
];

export const allSports = [
  'Football',
  'Basketball',
  'Baseball',
  'Softball',
  'Soccer',
  'Track & Field',
  'Swimming',
  'Volleyball',
  'Wrestling',
  'Lacrosse',
  'Hockey',
  'Golf',
  'Tennis',
  'Gymnastics',
  'Water Polo',
  'Rowing',
  'Cross Country'
];

export const divisions = [
  'NCAA D1',
  'NCAA D2',
  'NCAA D3',
  'NAIA',
  'NJCAA D1',
  'NJCAA D2',
  'NJCAA D3'
];