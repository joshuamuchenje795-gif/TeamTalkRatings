
  # Student Athlete Review Platform

  This is a code bundle for Student Athlete Review Platform. The original project is available at https://www.figma.com/design/iTTerDDI3c4bO9hhDnggi2/Student-Athlete-Review-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  